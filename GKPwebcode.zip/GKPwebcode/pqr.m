function [b_is, seb_is, fit_is, fit_oos, wts] = pqr(Y,X,Z,qtile,start,agghor,varargin)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Summary
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Partial quantile predictive regression of Y on X (using single factor)
%
% function [b_is seb_is fit_is fit_oos wts] = pqr(Y,X,Z,qtile,start,agghor,skipse,reqd)
%
% INPUTS
% Y             Forecast target (Tx1)
% X             Matrix of predictors (TxN)
% Z             Other predictors (TxM) -- can be empty
% qtile         Quantile
% start         Observation at which OOS forecasting begins
% agghor        Aggregation horizon (needed to ensure overlap accounted for in OOS)
% skipse        (optional) if passed, skip se calcualtion [for speed]. If reqd is passed, must be
%                 either turned off (by passing empty array/string) or turned on (anything else)
% reqd          (optional) if passed, sets the required number of training sample observations
%
% OUTPUTS
% b_is          In-sample 3rd-pass coeff
% seb_is        In-sample 3rd-pass coeff se
% fit_is        In-sample fitted values
% fit_oos       Out-of-sample fitted values
% wts           In-sample 2nd-pass coeff

dooos = true;
if nargin > 8, dooos = false; end
% Minimum number of observations required to be used in training sample
if length(varargin)>1, reqd = varargin{2}; varargin = varargin{1}; else; reqd = 60;end%reqd = 0.8;%[0,1]

% Housekeeping
%#ok<*WNOFF,*NASGU,*NOPTS,*MNEFF,*FNDSB,*FXSET>
format short;warning off

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% In Sample Forecasts
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Filtering X to create X_IS
X_IS = X;

[T N] = size(X_IS);
% Keep only obs with enough data
if reqd <=1
    X_IS = X_IS(:,sum(~isnan(X_IS))>=reqd*T);
else
    X_IS = X_IS(:,sum(~isnan(X_IS))>=reqd);
end
[T N] = size(X_IS);

% Standardize data
X_IS(end,:) = nan;
X_IS        = stdize(X_IS);
% add Z if nonempty
if ~isempty(Z)
    Z_IS = Z; Z_IS = stdize(Z_IS);
end

% First-pass quantile regressions
% Preallocate Phi
Phi  = nan(N,1);
iota = ones(T,1);
for i=1:N
    lagX   = lag(X_IS(:,i),1,nan);    
    [b,temp1,temp2]  = qr3(Y,[iota lagX],qtile,1);
    Phi(i)   = b(2);
end

wts = Phi;

% Second-pass OLS regressions
% Preallocate F
F = nan(T,1);
for t=1:T
    
    % Drop periods with too few observed predictors
    if sum(~isnan( X_IS(t,:)'+Phi ))<3, continue, end
    
    % Regression with constant
    stats = regstats(X_IS(t,:),Phi,'linear','beta');
    F(t)  = stats.beta(2);
end

% Third-pass quantile regression
% add Z if nonempty
if ~isempty(Z)
    F = [F Z_IS];
end
lagF      = lag(F,1,nan);
[b,seb,temp3] = qr3(Y,[iota lagF],qtile,1);

fit_is    = [iota lagF]*b;
b_is      = b(2);
seb_is    = seb(2);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Out of Sample
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Preallocated fitted values: _3prf from 3prf, _mean from recursive mean
fit_oos = nan(T,1);

% Recursive out-of-sample procedure
if dooos
for t = start:T-1
    
    % At this time t we will form the forecast for t+1

    % Reset subsample data with nans
    X_OOS        = nan(size(X));
    X_OOS(1:t,:) = X(1:t,:);
    % add Z if nonempty
    if ~isempty(Z)
        Z_OOS = nan(size(Z)); Z_OOS(1:t,:) = Z(1:t,:);
    end
    
    % Y, when aggregated, includes look-ahead info. Adjusts for this
    tempY                 = nan(size(Y));
    tempY(1:t-agghor+1,1) = Y(1:t-agghor+1);
    
    % Keep only obs with enough data
    if reqd <=1
        X_OOS = X_OOS(:,sum(~isnan(X_OOS))>=reqd*t);
    else
        X_OOS = X_OOS(:,sum(~isnan(X_OOS))>=reqd);
    end
    if isempty(X_OOS), continue, end
    [T N] = size(X_OOS);
    % Standardize data, this standardization only uses information
    % through t
    X_OOS = stdize(X_OOS);
    % add Z if nonempty
    if ~isempty(Z)% unnecessary
        Z_OOS = stdize(Z_OOS);
    end

    % First-pass quantile regressions
    % Preallocate and reset Phi
    Phi  = nan(N,1);
    for i=1:N
        
        lagX = lag(X_OOS(:,i),1,nan);
        [b,temp4,temp5] = qr3(tempY,[iota lagX],qtile,1);
        Phi(i)  = b(2);
    end
    
    % Second-pass OLS regressions
    % Preallocate and reset F
    F = nan(T,1);
    for tau=1:t
        
        % Drop periods with too few osberved predictors
        if sum(~isnan( X_OOS(tau,:)'+Phi ))<3, continue, end
        
        tmp    = ([ones(N,1) Phi]'*[ones(N,1) Phi])\([ones(N,1) Phi]'*X_OOS(tau,:)');
        F(tau) = tmp(2);
    end
    % NOTE: F is nan for t+1,t+2,...
    
    % Third-pass quantile regression (only using data through t)
    % add Z if nonempty
    if ~isempty(Z)
        F = [F Z_OOS];
    end
    lagF         = lag(F,1,nan);
    [b,temp6,temp7]      = qr3(tempY,[iota lagF],qtile,1);
    fit_oos(t+1) = [1 F(t,:)]*b;
    
    % Report calculation progress
    if floor(t/1e2)*1e2==t, disp(['pqr done with ' num2str(t) ' of ' num2str(T-1)]), end
end
end