function [betas,stdbetas,loss,V] = qr3(y,X,q,varargin)

% function [betas,stdbetas,loss] = qr3(y,X,q,varargin)
% INPUTS:
% y         Response variable n x 1 vector
% X         Matrix of regressors n x k vector
% q         Quantile i.e. 0.5 for median regression
% varargin  Optional argument, if passed skip std error calculation (default returns std error)
%
% OUTPUTS:
% betas     QR slope estimate
% stdbetas  Estimate std errors
% loss      Vector (n x 1) of losses
% V         std error matrix estimate


% Take out NaNs in X, only use available data
f=find(sum(isnan(X),2)==0 & isnan(y)==0); 
X=X(f,:);
y=y(f,:);


n = size(X,1);
k = size(X,2);
betas = 0;
betas = qr_koenk(X, y, q);


% Residuals & Losses
r    = y-X*betas;
loss = rho(r,q);
 
% Confidence intervals
if isempty(varargin)
    % Skip std error calcs
    stdbetas = nan(size(betas));
else
    if ~strcmp(varargin{1},'bootstrap')
        % Sheather and Maritz
        h=n^(-0.2)*( 4.5 * normpdf(norminv(q))^4 / (2*norminv(q)^2 + 1)^2 )^0.2;
        
        % Compute s(q)
        r=sort(r);
        xx=0:1/(n-1):1;
        f_l=r(find(q-h<xx,1,'first'));
        f_h=r(find(q+h<xx,1,'first'));
        
        s=(f_h-f_l)/2/h;
        
        if ~isempty(s)
            omega2=q*(1-q)*s^2;
            
            D=X'*X/n;
            
            V=(1/n)*omega2*inv(D);
            
            stdbetas=sqrt(diag(V));
        elseif isempty(s)
            stdbetas = nan(size(betas));
        end
    else
        % Residual block bootstrap
        T     = length(r);
        bsize = 6; % block size
        nboot = 500; % number of bootstrap samples
        bbt   = nan(length(betas),nboot);
        r2    = [r;r];
        stins = randi(T,ceil(T/bsize),nboot);
        for bsim = 1:nboot
            stin = cumsum( [stins(:,bsim) ones(ceil(T/bsize),bsize-1)] , 2 );
            stin = stin';
            rbt  = r2(stin(:));
            ybt  = X*betas + rbt(1:T,1);
            bbt(:,bsim) = qr_koenk(X,ybt,q);
        end
        V = cov(bbt');
        stdbetas = sqrt(diag(V));
    end
    
end
