function [b_is, seb_is, fit_is, fit_oos] = pcaqr(Y,X,Z,qtile,start,pcchoice,agghor,varargin)

% Quantile predictive regression of Y on X
%
% function [b_is seb_is fit_is fit_oos] = pcaqr(Y,X,Z,qtile,start,agghor,pcchoice,skipse,reqd)
%
% INPUTS
% Y             Forecast target (Tx1)
% X             Matrix of predictors (TxK)
% Z             Other predictors (TxM) -- can be empty
% qtile         Quantile
% start         Observation at which OOS forecasting begins
% pcchoice      Vector with PCs to use
% agghor        Aggregation horizon (needed to ensure overlap accounted for in OOS)
% skipse        (optional) if passed, skip se calcualtion [for speed]. If reqd is passed, must be
%                 either turned off (by passing empty array/string) or turned on (anything else)
% reqd          (optional) if passed, sets the required number of training sample observations

dooos = true;
if nargin > 9, dooos = false; end
% Minimum number of observations required to be used in training sample
if length(varargin)>1, reqd = varargin{2}; varargin = varargin{1}; else; reqd = 60;end%reqd = 0.8;%[0,1]

% Housekeeping
%#ok<*WNOFF,*NASGU,*NOPTS,*MNEFF,*FNDSB,*FXSET>
format short;warning off

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% In Sample Forecasts
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Filtering X to create X_IS
X_IS  = X;
% Variance-standardize data
X_IS  = stdize(X_IS);
% add Z if nonempty
if ~isempty(Z)
    Z_IS = Z; Z_IS = stdize(Z_IS);
end

XX    = X_IS(sum(isnan(X_IS),2)==0,:); % Remove nans

l     = princomp(XX);
npc   = length(pcchoice);
l     = l(:,pcchoice);
xgood = ~isnan(X_IS);
Xf    = nan(size(X_IS,1),npc);
for j=1:npc
    lgood   = bsxfun(@times,xgood,l(:,j)');
    L       = sqrt(diag(lgood*lgood'));
    Xf(:,j) = nansum(bsxfun(@times,X_IS,l(:,j)'),2)./L;
end
% add Z if nonempty
if ~isempty(Z)
    Xf = [Xf Z_IS];
end
T         = size(X_IS,1);
iota      = ones(T,1);
lagX      = lag(Xf,1,nan);

% if ~isempty(varargin)
%     [b,seb,temp1] = qr3(Y,[iota lagX],qtile);
% else
    [b,seb,temp1] = qr3(Y,[iota lagX],qtile,1);
% end
fit_is    = [iota lagX]*b;
b_is      = b(2:end);
seb_is    = seb(2:end);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Out of Sample
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Preallocated fitted values
fit_oos = nan(T,1);

% Recursive out-of-sample procedure
if dooos
for t = start:T-1
    
    % At this time we t will form the forecast for t+1
    
    % Reset subsample data with nans
    X_OOS        = nan(size(X));
    X_OOS(1:t,:) = X(1:t,:);
    % add Z if nonempty
    if ~isempty(Z)
        Z_OOS = nan(size(Z)); Z_OOS(1:t,:) = Z(1:t,:);
    end
    
    % Y, when aggregated, includes look-ahead info. Adjusts for this
    tempY                 = nan(size(Y));
    tempY(1:t-agghor+1,1) = Y(1:t-agghor+1);
    
    % Keep only obs with enough data
    if reqd <=1
        X_OOS = X_OOS(:,sum(~isnan(X_OOS))>=reqd*t);
    else
        X_OOS = X_OOS(:,sum(~isnan(X_OOS))>=reqd);
    end
    if isempty(X_OOS), continue, end

    % Variance standardize data, this standardization only uses information
    % through t
    X_OOS = stdize(X_OOS);
    % add Z if nonempty
    if ~isempty(Z) % unnecessary
        Z_OOS = stdize(Z_OOS);
    end
    
    XX=X_OOS(sum(isnan(X_OOS),2)==0,:); % Remove nans

    l     = princomp(XX);
    npc   = length(pcchoice);
    l     = l(:,pcchoice);
    xgood = ~isnan(X_OOS);
    Xf    = nan(size(X_OOS,1),npc);
    for j=1:npc
        lgood   = bsxfun(@times,xgood,l(:,j)');
        L       = sqrt(diag(lgood*lgood'));
        Xf(:,j) = nansum(bsxfun(@times,X_OOS,l(:,j)'),2)./L;
    end
    % add Z if nonempty
    if ~isempty(Z)
        Xf = [Xf Z_OOS];
    end
    lagX = lag(Xf,1,nan);
    
    
%     if ~isempty(varargin)
%         [b,temp2,temp3] = qr3(tempY,[iota lagX],qtile);
%     else
        [b,temp2,temp3] = qr3(tempY,[iota lagX],qtile,1);
%     end
    fit_oos(t+1) = [1 Xf(t,:)]*b;
    
    % Report calculation progress
    if floor(t/1e2)*1e2==t, disp(['pcaqr done with ' num2str(t) ' of ' num2str(T-1)]), end
end
end
