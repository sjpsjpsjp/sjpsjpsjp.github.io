function r=rho(x,q)

% rho function for quantile regressions

r=x.*(q*ones(size(x))-(x<0));