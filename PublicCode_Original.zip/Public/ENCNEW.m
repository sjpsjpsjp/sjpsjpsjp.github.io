function ENCNEW = ENCNEW(forerr1,forerr2)

% This calculates the ClarkMcCracken(2001) ENCNEW statistic for a recursive
% estimation scheme.

% inputs:
%   - vector of forecast errors -- the nested model
%   - vector of forecast errors -- the larger model's
% outputs:
%   - the value of ENCNEW

if size(forerr1,1) ~= size(forerr2,1)
    disp 'ENCNEW found an error when it was given two vectors of forecast errors of different dimension'
    return
end

loc = ~isnan(forerr1+forerr2);
P = sum(loc);

ENCNEW = P * nansum( forerr1(loc).^2 - forerr1(loc).*forerr2(loc) ) / nansum( forerr2(loc).^2 );
