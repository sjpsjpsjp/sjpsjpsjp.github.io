% KellyPruitt_JF2013_MktRet_FFBM
%
% Produces results on market return predictability from Fama-French portfolio BMs using
% target-proxy 3PRF; both in-sample and out-of-sample. Requires Stats toolbox and some
% code from LeSage's spatial econometric toolboxes

% Copyright Bryan Kelly and Seth Pruitt
%
% Please cite as Kelly, Bryan and Seth Pruitt. "Market Expectations in the Cross Section of Present
% Values." Journal of Finance, October 2013, 68(5): 1721-1756

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Startup Always
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc
who_are_you = 'seth';

if strcmp(who_are_you,'seth')
    directory = 'c:/sjp/dropbox/';
elseif strcmp(who_are_you,'bryan')
    directory = '/Users/bkelly0/Dropbox/';
end

dataloc  = [directory 'DisaggValRatio/Data/Public/'];
codeloc  = [directory 'DisaggValRatio/Code/Public/'];
saveloc  = [directory 'DisaggValRatio/Data/Public/'];


cd( codeloc )
addpath('../common');

%#ok<*PRTCAL,*ALIGN>

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Choices
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% sample
% Sample of portfolios' value ratios
%  choices: 
%   6, 25, 100
sample = 100

% maxyr, minyr
% Years to use
%   from 1930 to 2010;
minyr = 1930; % positive integer
maxyr = 2010; % positive integer

% twelvemcum
% Twelve-month cumulative returns
%  'on' means we forecast 12-month cumulative returns; 'off' means 1-month returns
twelvemcum = 'on'; % 'on' or 'off'

% savemat
% true or false: true saves mat file with results
savemat = false;


% Housekeeping
%#ok<*WNOFF,*NASGU,*NOPTS,*MNEFF,*FNDSB,*FXSET>
format short;warning off



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data Work
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Load market return data and times
load([dataloc 'mkt_ret_monthly']);
R     = log_mktret;
Rtime = ffdates;

% Construct 12m cumulative returns, if desired
if strcmp(twelvemcum, 'on')
    annR = nan(size(R));
    for t=1:length(R)-11,
        annR(t) = sum(R(t:t+11));
    end
    R = annR; clear annR
    % NOTE: so now R(t) is the cumulative return for t:t+11
end

% Load value ratios
load([dataloc ...
    num2str(sample) ...
    '-size-BM ptfs 1927-2010 Ken French Data']);
V = bm;
Vtime = yrmolist;


% Intersect data
[datatime RI VI] = intersect(Rtime,Vtime,'rows'); % where the data overlaps
t1 = find( datatime == minyr*100+1 );
if isempty(t1), t1 = 1; minyr = floor(datatime(1,:)/100); end
t2 = find( datatime == maxyr*100+12 );
if isempty(t2), t2 = length(datatime); maxyr = floor(datatime(end,:)/100); end
R       = R(RI(t1:t2),1);
V       = V(VI(t1:t2),:);

datatime = datatime(t1:t2);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% In Sample Forecasts
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Filtering V to create V_IS
V_IS = V;
% Keep only obs with enough data
V_IS = V_IS(:,sum(~isnan(V_IS))>=0.8*size(V_IS,1));
[T N] = size(V_IS);
% Variance standardize data
V_IS = bsxfun(@times,V_IS,1./nanstd(V_IS));

% First-pass regressions
% Preallocate Phi
Phi = nan(N,1);
for i=1:N
    
    lagV = lag(V_IS(:,i),1,nan);
    
    stats = regstats(lagV,R,'linear','beta');
    Phi(i) = stats.beta(2);
end

% % Enforce normalization to use KP's asymptotics
% Phi = Phi/chol(cov(Phi,1));

% Second-pass regressions
% Preallocate F
F = nan(T,1);
for t=1:T
    
    % Drop periods with too few observed predictors
    if sum(~isnan( V_IS(t,:)'+Phi ))<6, continue, end
    
    stats = regstats(V_IS(t,:),Phi,'linear','beta');
    F(t) = stats.beta(2);
end

% Third-pass regression
lagF = lag(F,1,nan);
stats = regstats(R,lagF,'linear',{'rsquare','yhat','beta','r'});
ISR2 = 100*stats.rsquare
fit_is = stats.yhat;
beta = stats.beta(2);

% KP t-stat
J = inline('eye(x)-(1/x)*ones(x)');
t_KPs = nan(12,1);
if strcmp(twelvemcum,'on') % 12m returns -- use non-overlapping only
    for m=1:12
        tmp = 0; Fm = mean(F); Tct = 0; Fct = [];
        for t=m:12:T
            tmp1 = stats.r(t)^2*(F(t,:)-Fm)'*(F(t,:)-Fm);
            if isnan(tmp1)
                tmp = tmp + 0;
                Tct = Tct + 0;
                Fct = Fct;
            else
                tmp = tmp + tmp1;
                Tct = Tct + 1;
                Fct = [Fct;F(t,:)];
            end
        end
        tmp = tmp/Tct;
        avar_beta       = ( ((Tct^-1)*Fct'*J(Tct)*Fct)\tmp )/( (Tct^-1)*Fct'*J(Tct)*Fct );
        t_KPs(m) = beta ./ sqrt(diag(avar_beta)/Tct);
    end
    t_KP = median(t_KPs);
    disp(['t_KP is ' num2str(t_KP)])
else % 1m -- use all
    tmp = 0; Fm = mean(F); Tct = 0; Fct = [];
    for t=1:T
        tmp1 = stats.r(t)^2*(F(t,:)-Fm)'*(F(t,:)-Fm);
        if isnan(tmp1)
            tmp = tmp + 0;
            Tct = Tct + 0;
            Fct = Fct;
        else
            tmp = tmp + tmp1;
            Tct = Tct + 1;
            Fct = [Fct;F(t,:)];
        end
    end
    tmp = tmp/Tct;
    avar_beta       = ( ((Tct^-1)*Fct'*J(Tct)*Fct)\tmp )/( (Tct^-1)*Fct'*J(Tct)*Fct );
    t_KP = beta ./ sqrt(diag(avar_beta)/Tct);
    disp(['t_KP is ' num2str(t_KP)])
end

% NW t-stat
if strcmp(twelvemcum,'on')
    loc = 2:length(R)-11;
    neweywest = nwest(R(loc),[ones(size(R(loc))) lagF(loc)],11);
else
    loc = 2:length(R);
    neweywest = nwest(R(loc),[ones(size(R(loc))) lagF(loc)],0);
end
t_NW = neweywest.tstat(2:end);
disp(['t_NW is ' num2str(t_NW)])

% Hodrick t-stat
if strcmp(twelvemcum,'on')
    hodrick = hodrick_pred(R,lagF,13);
else
    hodrick = hodrick_pred(R,lagF,1);
end
t_Hodrick = hodrick.t_hod(2:end);
disp(['t_Hodrick is ' num2str(t_Hodrick)])


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Out of Sample
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Preallocated fitted values: _3prf from 3prf, _mean from recursive mean
fit_3prf = nan(T,1);
fit_mean = nan(T,1);

% Recursive out-of-sample procedure
for t=60:T-1
    
    % At this time t we will form the forecast for t+1
    
    % Reset tempR with nans
    tempR = nan(size(R));
    V_OOS = nan(size(V));
    V_OOS(1:t,:) = V(1:t,:);
    % If 12m return forecast, tempR ends at t-11 which is the return for t-11:t
    % If 1m return forecast, tempR ends at t which is the return for t
    if strcmp(twelvemcum,'on')
        tempR(1:t-11) = R(1:t-11);
    else
        tempR(1:t) = R(1:t);
    end
    % NOTE: tempR is nan for t+1,t+2,... . Therefore we use information only through t
    

    % Keep only obs with enough data
    V_OOS = V_OOS(:,sum(~isnan(V_OOS))>=0.8*t);
    if isempty(V_OOS), continue, end
    [T N] = size(V_OOS);
    % Variance standardize data, this standardization only uses information
    % through t
    V_OOS = bsxfun(@times,V_OOS,1./nanstd(V_OOS));

    
    
    % Check for enough market returns; if too few, go to next iteration
    if sum(~isnan(tempR))<60+1, continue, end

    % First-pass regressions
    % Preallocate and reset Phi
    Phi = nan(N,1);
    for i=1:N
        
        lagV = lag(V_OOS(:,i),1,nan);
        
        stats = regstats(lagV(1:t,:),tempR(1:t,:),'linear','beta');
        Phi(i) = stats.beta(2);
    end
    % NOTE: because tempR has been set according to twelvemcum with the proper number of nans, these
    % regressions use only information known at time t

    % Enforce normalization to use KP's asymptotics
    Phi = Phi/chol(cov(Phi,1));
    
    % Second-pass regressions
    % Preallocate and reset F
    F = nan(T,1);
    for tau=1:t
        
        % Drop periods with too few osberved predictors
        if sum(~isnan( V_OOS(tau,:)'+Phi ))<6, continue, end
        
        stats = regstats(V_OOS(tau,:),Phi,'linear','beta'); 
        F(tau) = stats.beta(2);
    end
    % NOTE: F is nan for t+1,t+2,...
    
    % Third-pass regression (only using data through t)
    lgF = lag(F,1,nan);
    stats = regstats(tempR(1:t,:),lgF(1:t,:),'linear','beta');
    fit_3prf(t+1) = stats.beta(1) + F(t)*stats.beta(2);
    
    % Recursive mean (only data through t)
    fit_mean(t+1) = nanmean(tempR);
    
    % Report calculation progress
    if floor(t/100)*100==t, t, end
end



% Calculate OOS R2s coming from various choices of training samples
oosr2 = nan(T,1); oosenc = nan(T,1);
for t=60:T-60
    loc = t:T;
    loc1 = find(~isnan(R(loc)+fit_3prf(loc)+fit_mean(loc)));
    oosr2(t) = 1-sum( (R(loc(loc1))-fit_3prf(loc(loc1))).^2 )/...
        sum( (R(loc(loc1))-fit_mean(loc(loc1))).^2 );
    if strcmp(twelvemcum,'off')
        oosenc(t) = ENCNEW( (R(loc(loc1))-fit_mean(loc(loc1))) , (R(loc(loc1))-fit_3prf(loc(loc1))) );
    else
        oosenc(t) = ENCNEW_NW( (R(loc(loc1))-fit_mean(loc(loc1))) , (R(loc(loc1))-fit_3prf(loc(loc1))) , 12);
    end
end
oosr2 = oosr2*100;


if savemat
    if strcmp(twelvemcum, 'off')
        filename = [saveloc 'MktRet_FFBM_' num2str(sample) '_' num2str(minyr) '_' num2str(maxyr) '_ptfs_1m.mat' ]
    else
        filename = [saveloc 'MktRet_FFBM_' num2str(sample) '_' num2str(minyr) '_' num2str(maxyr) '_ptfs_12m.mat' ]
    end
    save(filename,'V','R',...
        'ISR2','oosr2','oosenc','datatime',...
        'minyr','maxyr','twelvemcum','sample',...
        'fit_is','fit_3prf','fit_mean',...
        't_KP','t_KPs','t_NW','t_Hodrick')
end
       

