function ENCNEW = ENCNEW_NW(forerr1,forerr2,K)

% This calculates the ClarkMcCracken(2001) ENCNEW statistic for a recursive
% estimation scheme, for serially-correlated errors

% inputs:
%   - forerr1 : vector of forecast errors -- the nested model
%   - forerr2 : vector of forecast errors -- the larger model's
%   - K       : number of lags (0 for White standard errors)
% outputs:
%   - the value of ENCNEW
%
% Uses utl_HAC

if size(forerr1,1) ~= size(forerr2,1)
    disp 'ENCNEW found an error when it was given two vectors of forecast errors of different dimension'
    return
end

if exist('utl_HAC','file')~=2 % check that utl_HAC is in path
    disp('utl_HAC is''nt in the path or current directory -- ENCNEW_NW is outputting Inf')
    ENCNEW = inf;
    return
end

loc = ~isnan(forerr1+forerr2);
P = sum(loc);

denom = utl_HAC(forerr2(loc),K,'neweywest1987');

ENCNEW = P * nansum( forerr1(loc).^2 - forerr1(loc).*forerr2(loc) ) / (denom*sum(loc));
