function [forecasts pointests avarests] = estimate3PRF(y,X,Z,varargin)
% [forecasts] = estimate3PRF(y,X,Z)
% [forecasts] = estimate3PRF(y,X,Z,flag1,value1,...)
% [forecasts pointests avarests] = estimate3PRF(y,X,Z,flag1,value1,...)
%
% INPUTS
% - y  : (T x 1) time series of target variable
% - X  : (T x N) matrix of predictors' time series
% - Z  : (T x L) matrix of proxies' time series 
%         *OR* scalar choice for choice of L automatic proxies
%
%     NOTE: The timing between y and X/Z must be adjusted before being passed -- we assume that
%     the t-th row of X is being used to forecast the t-th row of y, and that the t-th row of Z
%     are the proxies used to extract info from the t-th row of X.  This means that y (or X/Z)
%     should be properly led (lagged) before being passed.
%
%     *Flags*
%     - 'type' : 'IS Full' (default), 'OOS Recursive', 'OOS Cross Val' , 'OOS Rolling'
%
%     - 'window' : 2-vector such as [ <number of obs before forecasted to drop> , <number of obs
%     total to drop> ] (default [0 1]); used by OOS Cross Val
%
%     - 'mintrain' : EITHER (1) scalar choice of smallest number of observations for training
%     sample (default = round(T/2)); OR (2) 2-vector with smallest number as
%     in (1) and <gap between training estimation window and first forecast constructed> (default =
%     0). Note: sets number of non-missing observations required for each predictor to be included
%     in the training sample; used by OOS Recursive
%
%     - 'rollwin' : EITHER 2-vector such as [<number of obs in rolling window> , <number of
%     nonmissing obs required for that predictor to be included in the training sample>] (default
%     [30 20]); OR 3-vector with last element <gap between training estimation window and first
%     forecast constructed> (default = 0); used by OOS Rolling
%       *** Currently the value of rollwin(2) is not used ***
%
%     - 'pls' : 'on' or 'off' (default), runs PLS version which normalizes X and runs 1st and 2nd
%     stages without constants [only if scalar is passed for Z]
%
%     - 'toolarge' : true or false (default), avoids alpha and avarests estimation in 'IS Full'
%
%     - 'normalize' : false or true (default), normalizes all Xs to have unit variance
%
% OUTPUTS
% - forecasts : (T x 1) time series of forecasts
% - pointests : structure of point estimates with following fields
%     -- forecasts : (T x 1) time series of forecasts
%     -- ferrors   : (T x 1) time series of forecast errors
%     -- rsquare   : R2 (can be negative for OOS) when compared to rolling historical mean
%     -- encnew    : (non-nan when OOS Recursive) value of Clark and McCracken's (2001) ENC-NEW statistic
%     -- rollfore  : (T x 1) time series of rolling mean forecasts when OOS; nan otherwise
%                 *** THE FOLLOWING ARE COMPUTED FOR 'IS Full' -- otherwise not computed ***
%     -- alpha     : (N x 1) coefficient
% - avarests : structure of estimates of asymptotic variances if 'IS Full' with following fields
%     -- forecasts : (T x 1) estimate of asymp covariance of time t forecast
%     -- alpha     : (N x N) estimate of asymp covariance matrix of alpha
%
% DESCRIPTION: Computes Three-Pass Regression Filter (Bryan Kelly and Seth Pruitt, ``The Three-Pass
% Regression Filter: A New Approach to Forecasting Using Many Predictors''); see paper for more
% details.
%
% Please cite as: Kelly, Bryan and Seth Pruitt (2011): ``The Three-Pass Regression Filter: A New
% Approach to Forecasting Using Many Predictors,'' Working Paper, Chicago Booth.
%
% Assumes the data are timed as follows:
%   - y = (y[h+1] ,y[h+2] ,...,y[T+h])'
%   - X = (x[1]',  x[2]'  ,...,x[T]' )'
% A future realized variable (like the target itself) might be one of the proxies, as well as other
% variables realized at time t+h.
%
% Requires Stats toolbox (nanstd.m,nanmean.m,regress.m)

% Copyright 2010, Bryan Kelly and Seth Pruitt First Version: 2010-12-30 This Version: 2011-8-23

% The percentage of non-missings required is currently hard-coded as the first line in the
% non-nested function regress2

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Preliminary Checking
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% size checking
[T tmp] = size(y);
if tmp~=1, error(['y should have col dim 1, but has col dim ' num2str(tmp)]), end
[tmp N] = size(X);
if tmp~=T, error(['X should have row dim ' num2str(T) ' like y, but has row dim ' num2str(tmp)]), end
[tmp L] = size(Z); 
if isscalar(Z), autoproxy = 'on'; L=Z;
elseif tmp~=T, error(['Z should have row dim ' num2str(T) ' like y, but has row dim ' num2str(tmp)]),
else autoproxy = 'off';end

% check for flags
if nargin > 3, flagspassed = true; else flagspassed = false; end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Flag/Paramater Combos
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Flags we look for
possibleflags = {'type','window','mintrain','pls','rollwin','toolarge','normalize'};
possibletypes = {'IS Full' ; ...
                'OOS Recursive'; ...
                'OOS Cross Val'; ...
                'OOS Rolling'};

% Defaults
procedure   = 'IS Full'; % IS Full
window      = [0 1]; % one observation between last estimation obs and first forecast obs, three dropped observations altogether
mintrain    = round(T/2); % 1st element default: first training sample is half as long as full sample
pls         = 0;
rollwin     = [30 20 0]; % 30 obs in the window, 20 required nonmissing, 0 gap between training and forecast
toolarge    = false;
normalize   = true;

if flagspassed
    for fl=1:2:nargin-3
        flag = varargin{fl};
        fval = varargin{fl+1};
        fm = strmatch(flag,possibleflags);
        if isempty(fm)
            error(['Unknown flag name -- ' flag])
        elseif length(fm)>1
            error(['Ambiguous flag name -- ' flag])
        end % if we get through here, the flag is uniquely recognizable
        
        switch flag
            case 'type'
                tm   = strmatch(fval,possibletypes(:,1),'exact');
                if isempty(tm)
                    error(['Unknown type name -- ' fval])
                elseif length(tm)>1
                    error(['Ambiguous type name -- ' fval ' -- going with default'])
                end % if we get through here, the type is uniquely recognizable
                procedure = fval;
                
            case 'window'
                window = fval;
            case 'mintrain'
                mintrain = fval;
            case 'pls'
                pls = strcmp(fval,'on');
            case 'rollwin'
                rollwin = fval;
        end
        
    end
end

% 2nd element of mintrain default
if isscalar(mintrain), mintrain = [mintrain 0]; end

% 3rd element of rollwin default
if length(rollwin)==2, rollwin = [rollwin(:) ; 0 ]; end

% pls=1 only if autoproxy=1
if pls==1 && strcmp(autoproxy,'off'), pls=0; end

if normalize
    % Unit variance for X
    X = X ./ repmat( nanstd(X) , size(X,1) , 1 );
    %X = bsxfun(@rdivide,X,nanstd(X));
end

% enforce nonnegativity
rollwin = abs(rollwin); mintrain = abs(mintrain); window = abs(window);





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Forecast Construction
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

switch procedure
    
    case 'IS Full'
        if strcmp(autoproxy,'on')
            r0 = y;
            for j=1:L
                if j~=L
                    forecasts = t3prf(y,X,r0,pls);
                else
                    [forecasts jnk F B] = t3prf(y,X,r0,pls);
                end
                r0 = [r0 y-forecasts];
                if nargout>1 && j==L % for possible use with pointests/avarests below
                    Z = r0(:,1:end-1);
                end
            end
        else
            forecasts = t3prf(y,X,Z,pls);
        end
        % Additional pointests and avarests (if called)
        if nargout>1
            pointests.forecasts = forecasts;
            pointests.ferrors   = y-forecasts;
            loc                 = find(~isnan(pointests.ferrors));
            pointests.rsquare   = 1 - nanvar( pointests.ferrors(loc) )/nanvar( y(loc) );
			pointests.encnew    = nan;
            pointests.rollfore  = nan(size(y));
            pointests.proxies   = Z;
            
            % Possible additional for IS Full
            if toolarge
                pointests.alpha = nan(size(X,2),1);
                %pointests.beta  = B(2:end);
                %pointests.factors = F;
                avarests = nan;
            else
                pointests.alpha     = ...
                    J(N)*X'*J(T)*Z/(Z'*J(T)*X*J(N)*X'*J(T)*X*J(N)*X'*J(T)*Z)*Z'*J(T)*X*J(N)*X'*J(T)*y;
                %pointests.beta      = B(2:end);
                %pointests.factors   = F;
                if nargout>2
                    tmp = 0; tmp2 = 0;
                    Xm = mean(X); Fm = mean(F);
                    Omega_a = J(N)*( (T^-1)*X'*J(T)*Z )/...
                        ( (T^-3)*(N^-2)*Z'*J(T)*X*J(N)*X'*J(T)*X*J(N)*X'*J(T)*Z )*...
                        ( (T^-1)*(N^-1)*Z'*J(T)*X*J(N) );
                    for t=1:T
                        tmp  = tmp + (T^-1)*pointests.ferrors(t)^2*(X(t,:)-Xm)'*(X(t,:)-Xm);
                        tmp2 = tmp2+ (T^-1)*pointests.ferrors(t)^2*(F(t,:)-Fm)'*(F(t,:)-Fm);
                    end
                    avarests.alpha      = Omega_a*tmp*Omega_a';
                    avarests.forecasts  = (N^-2)*J(T)*X*avarests.alpha*X'*J(T);
                    avarests.beta       = ( ((T^-1)*F'*J(T)*F)\tmp2 )/( (T^-1)*F'*J(T)*F );
                else
                    avarests = nan;
                end
            end
            
        end
            
        
    case 'OOS Cross Val'
        if strcmp(autoproxy,'on')
            forecasts = nan(size(y));
			rollyfore = nan(size(y));
            for t=1:T
                Tscript = setdiff( 1:T , t-window(1):t-window(1)+window(2)-1 );
                yt = y(Tscript,1); Xt = X(Tscript,:);
                r0 = yt;
                for j=1:L
                    [tmp tmpt] = t3prf(yt,Xt,r0,pls,X(t,:));
                    r0  = [yt-tmp r0];
                end
                forecasts(t) = tmpt;
				rollyfore(t) = nanmean(yt);
            end
        else
            forecasts = nan(size(y));
			rollyfore = nan(size(y));
            for t=1:T
                Tscript = setdiff( 1:T , t-window(1):t-window(1)+window(2)-1 );
                yt = y(Tscript,1); Xt = X(Tscript,:); Zt = Z(Tscript,:);
                [tmp tmpt] = t3prf(yt,Xt,Zt,pls,X(t,:));
                forecasts(t) = tmpt;
				rollyfore(t) = nanmean(yt);
            end
        end
        % Additional pointests and avarests (if called)
        if nargout>1
            pointests.forecasts = forecasts;
            pointests.ferrors   = y-forecasts;
            loc                 = find(~isnan(pointests.ferrors));
            pointests.rsquare   = 1 - nansum( pointests.ferrors(loc).^2 )/nansum( (y(loc)-rollyfore(loc)).^2 );
			pointests.encnew    = nan;
            pointests.rollfore  = rollyfore;
            pointests.alpha     = nan(size(X,2),1);
        end
        avarests = nan;
        
    case 'OOS Recursive'
        if strcmp(autoproxy,'on')
            forecasts = nan(size(y));
			rollyfore = nan(size(y));
            for t=mintrain(1)+1+mintrain(2):T
                Tscript = 1:t-1-mintrain(2);
                yt = y(Tscript,1); Xt = X(Tscript,:);
                r0 = yt;
                for j=1:L
                    [tmp tmpt] = t3prf(yt,Xt,r0,pls,X(t,:));
                    r0  = [yt-tmp r0];
                end
                forecasts(t) = tmpt;
				rollyfore(t) = nanmean(yt);
            end
        else
            forecasts = nan(size(y));
			rollyfore = nan(size(y));
            for t=mintrain(1)+1+mintrain(2):T
                Tscript = 1:t-1-mintrain(2);
                yt = y(Tscript,1); Xt = X(Tscript,:); Zt = Z(Tscript,:);
                [tmp tmpt] = t3prf(yt,Xt,Zt,pls,X(t,:));
                forecasts(t) = tmpt;
				rollyfore(t) = nanmean(yt);
            end
		end
        % Additional pointests and avarests (if called)
        if nargout>1
            pointests.forecasts = forecasts;
            pointests.ferrors   = y-forecasts;
            loc                 = find(~isnan(pointests.ferrors));
            pointests.rsquare   = 1 - nansum( pointests.ferrors(loc).^2 )/nansum( (y(loc)-rollyfore(loc)).^2 );
			pointests.encnew    = encnew(rollyfore(loc),pointests.ferrors(loc));
            pointests.rollfore  = rollyfore;
            pointests.alpha     = nan(size(X,2),1);
        end
        avarests = nan;
        
    case 'OOS Rolling'
        if strcmp(autoproxy,'on')
            forecasts = nan(size(y));
			rollyfore = nan(size(y));
            for t=rollwin(1)+1+rollwin(3):T
                Tscript = t-rollwin(1)-rollwin(3):t-1-rollwin(3);
                yt = y(Tscript,1); Xt = X(Tscript,:);
                r0 = yt;
                for j=1:L
                    [tmp tmpt] = t3prf(yt,Xt,r0,pls,X(t,:));
                    r0 = [yt-tmp r0];
                end
                forecasts(t) = tmpt;
				rollyfore(t) = nanmean(yt);
            end
        else
            forecasts = nan(size(y));
			rollyfore = nan(size(y));
            for t=rollwin(1)+1+rollwin(3):T
                Tscript = t-rollwin(1)-rollwin(3):t-1-rollwin(3);
                yt = y(Tscript,1); Xt = X(Tscript,:); Zt = Z(Tscript,:);
                [tmp tmpt] = t3prf(yt,Xt,Zt,pls,X(t,:));
                forecasts(t) = tmpt;
				rollyfore(t) = nanmean(yt);
            end
        end
        % Additional pointests and avarests (if called)
        if nargout>1
            pointests.forecasts = forecasts;
            pointests.ferrors   = y-forecasts;
            loc                 = find(~isnan(pointests.ferrors));
            pointests.rsquare   = 1 - nansum( pointests.ferrors(loc).^2 )/nansum( (y(loc)-rollyfore(loc)).^2 );
			pointests.encnew    = nan;
            pointests.rollfore  = rollyfore;
            pointests.alpha     = nan(size(X,2),1);
        end
        avarests = nan;
        
    otherwise
        error('Type not recognized!')
                
end

           



end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% END OF MAIN FUNCTION
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% NonNested Helper Functions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%
% t3prf
%%%%%%%
function [yhat yhatt varargout] = t3prf(y,X,Z,pls,varargin)

% Preliminaries
N     = size(X,2);
T     = size(y,1);
L     = size(Z,2);
Phi   = nan(N,L);
Sigma = nan(T,L);

if pls
    Xm = nanmean(X);
    Xd = X - repmat(Xm,T,1);
end

% 3PRF
for i=1:N
    if pls
        phi      = regress2( Xd(:,i) , Z );
        Phi(i,:) = phi(1:end);
    else
        phi      = regress2( X(:,i) , [iota(T) Z] );
        Phi(i,:) = phi(2:end);
    end
end

usable = all(~isnan(Phi),2);N=sum(usable);
Phi = Phi( usable , : );

% Factors out, normalization, if called
if nargin<5 && nargout>2
    Phi = Phi/chol(cov(Phi,1));
end

for t=1:T
    if pls
        if sum(all(~isnan(bsxfun(@times,Xd(t,usable)',Phi)),2)) <= 5
            disp(['Pants on fire1 at ' num2str(t)])
            Sigma(t,:) = nan;
        else
            sigma      = regress( Xd(t,usable)' , Phi );
            Sigma(t,:) = sigma(1:end);
        end
    else
        if sum(all(~isnan(bsxfun(@times,X(t,usable)',Phi)),2)) <= 5
            disp(['Pants on fire2 at ' num2str(t)])
            Sigma(t,:) = nan;
        else
            sigma      = regress( X(t,usable)' , [iota(N) Phi] );
            Sigma(t,:) = sigma(2:end);
        end
    end
end
beta  = regress( y , [iota(T) Sigma] );
yhat = [iota(T) Sigma]*beta;

% Out-of-sample forecast construction, if called
yhatt = nan;
if nargin>4 % varargin{1} contains the an out-of-sample x to create an out-of-sample forecast
    Xt = varargin{1}; % should be a row vector
    if pls
        if sum(all(~isnan(bsxfun(@times,Xt(usable)'-Xm(usable)',Phi)),2)) <= 5
            disp(['Pants on fire3 at ' num2str(t)])
            yhatt = nan;
        else
            sigma = regress( Xt(usable)'-Xm(usable)'           , Phi  );
            yhatt = [1 sigma(1:end)']*beta;
        end
    else
        if sum(all(~isnan(bsxfun(@times,Xt(usable)',Phi)),2)) <= 5
            disp(['Pants on fire4 at ' num2str(t)])
            yhatt = nan;
        else
            sigma = regress( Xt(usable)'      , [iota(N) Phi] );
            yhatt = [1 sigma(2:end)']*beta;
        end
    end
end
% Factors out for in-sample, if called
if nargin<5 && nargout>2
    varargout(1) = {Sigma};
    varargout(2) = {beta};
end

end

%%%%%%
% iota
%%%%%%
function out = iota(NorT)
out = ones(NorT,1);
end

%%%
% J
%%%
function out = J(NorT)
out = eye(NorT)-(1/NorT)*ones(NorT);
end

%%%%%%%%%%
% regress2
%%%%%%%%%%
function b = regress2(y,x,varargin)
% nonmissing percentage required -- HARD CODE
nonmisperreq = .75;
tmp = all( ~isnan(bsxfun(@plus,y,x)) , 2);
if sum(tmp)/size(tmp,1) >= nonmisperreq || sum(tmp)>=100
    b = regress(y,x);
else
    b = nan(size(x,2),1);
end
end

function ENCNEW = encnew(forerr1,forerr2)

% This calculates the ClarkMcCracken(2001) ENCNEW statistic for a recursive
% estimation scheme.

% inputs:
%   - vector of forecast errors -- the nested model
%   - vector of forecast errors -- the larger model's
% outputs:
%   - the value of ENCNEW

if size(forerr1,1) ~= size(forerr2,1)
    disp 'ENCNEW found an error when it was given two vectors of forecast errors of different dimension'
    return
end

loc = ~isnan(forerr1+forerr2);
P = sum(loc);

ENCNEW = P * nansum( forerr1(loc).^2 - forerr1(loc).*forerr2(loc) ) / nansum( forerr2(loc).^2 );
end