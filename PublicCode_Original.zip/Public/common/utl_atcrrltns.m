function [acs,ph] = utl_atcrrltns(x,p,varargin)
% [acs] = utl_atcrrltns(x,p)
% [acs,ph] = utl_atcrrltns(x,p,'graph')
% [acs,ph] = utl_atcrrltns(x,p,'graph',levels)
% [acs,ph] = utl_atcrrltns(x,p,'graph',levels,'partial')
% input
% - x : (n x m) matrix with data in columns
% - p : max number of autocorrelations to look for
% - (optional) 'graph' : put if you want to graph autocorrelogram for each column
% - (optional) levels : cell array of absolute values of correlation at which to draw vertical line
% - (optional) 'partial' : graph partial autocorrelation coefs -- NOT WORKING
% output
% - acs : (p x m) matrix of autocorrelations
% - ph : figure handle(s) (if 'graph' is passed)
%
% Uses statistical toolbox.
%
% 'partial' option not working

[n,m] = size(x);
acs = NaN(p,m);
ph = NaN(m,1);
if nargin >= 3 && strmatch(varargin{1},'graph')
    graph = 1;
else graph = 0;
end

if nargin >= 4
    levels = varargin{2};
    lvs = NaN(p,length(levels));
else levels = [];
end

pch = 0;
if nargin >= 5 && strmatch(varargin{3},'partial')
    pch = 1;
end


for i=(1:m)
    for j=(1:p)
        switch pch
            case 0
                [tmpR,tmpP] = nancorr( x(1+j:end,i) , x(1:end-j,i) );
            case 1
                [tmpR,tmpP] = partialcorr( [x(1+j:end,i) x(1:end-j,i)] , ones(size(x(1+j:end,i))));
                tmpl = 2/sqrt(length(x(1:j:end,i)));
                tmpl = tmpl*ones(2);
                tmpl = tmpR-tmpl;
        end
        acs(j,i) = tmpR;
        if ~isempty(levels)
            for k=(1:length(levels))
                lvs(j,k) = tmpR(2,1)-tmpl(2,1);
            end
        end
    end
    if graph
        ph(i) = figure;
        bar( acs(:,i) )
        title(['Column ' num2str(i)])
        xlabel('Lag')
        ylabel('Autocorrelation')
        axis([0 p+1 -1 1])
        if ~isempty(levels)
            hold on
            for k=(1:length(levels))
                plot( lvs(:,k) , ':k')
                plot( -lvs(:,k) , ':k')
            end
            hold off
        end
    end
end
    