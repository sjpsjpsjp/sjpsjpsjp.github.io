function hod_stats = hodrick_pred(Y,X,K)

% Predictive Regression with t-stats using Hodrick (1992) standard errors
% Y = forecasting target
% X = predictor matrix
% K = periods aggregated 
%
% NOTES: 
% 1) K=1 is no overlap, K=2 is one period overlap, etc.
% 2) X lagged within file, so pass to function as contemporaneous variable

[T Nx] = size(X);

for j=1:Nx
    X(:,j) = stdize(X(:,j));
end

stats  = regstats(Y,lag(X,1,nan),'linear',{'rsquare','tstat','r'});
e      = stats.r;
X      = [ones(size(e)) X];

% Calculate OLS t-stats
Exx = zeros(size(X,2));
for t=1:T;
    if isnan(sum(X(t,:))), continue, end
    Exx = Exx + X(t,:)'*X(t,:);
end
Exx = Exx/T;
se_ols = sqrt( diag( nanvar(e)*inv(Exx) )/T ); 

% Calculate Hodrick t-stats
if K==1,
    se = se_ols;
else
    S = zeros(Nx+1);
    for t=1:length(e)-K;
        if isnan(sum(sum(X(t:t+K-1,:)))) || isnan(e(t+K)), continue, end
        wK = e(t+K)*nansum(X(t:t+K-1,:));
        S = S + wK'*wK;
    end
    S = S/T;
    se = sqrt( diag( inv(Exx)*S*inv(Exx) )/T/K );         
end

hod_stats.beta    = stats.tstat.beta;
hod_stats.se      = se;    
hod_stats.t_hod   = hod_stats.beta./se;    
hod_stats.t_ols   = hod_stats.beta./se_ols;    
hod_stats.rsquare = stats.rsquare;
hod_stats.n       = T;
  
    
%#ok<*MINV>