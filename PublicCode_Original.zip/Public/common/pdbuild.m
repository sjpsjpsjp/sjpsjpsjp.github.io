function [logPD log_ptfret log_ptfd]= pdbuild(sample,minyr,maxyr,dataloc,nonzero_div,source,form_mo,freq,minsize,sim_or_seq,breaks)
 
%#ok<*FNDSB,*NODEF,*NASGU>


if ~strcmp(sample,'indiv')
    if strcmp(source,'French')
        filename = [dataloc 'Fama-French-Portfolio-PDs/Monthly/' sample ' ptfs 1929-2009 Ken French Data'];
    else
        filename = [dataloc 'Portfolio-PDs/form_mo_' num2str(form_mo) '/' sample ' ptfs 1929-2009_monthly'];
        
        if form_mo==99 || form_mo==6 || form_mo==12
            filename = [filename '_sorts_' sim_or_seq '__breaks_' breaks];
            if nonzero_div == 0,
                filename = [filename '_-div-filter-off'];
            end
        else
            if nonzero_div == 0,
                filename = [filename '-div-filter-off'];
            end
        end
        
    end
    load(filename);

    if strcmp(freq,'annual')
        loc = find( yrmolist>=minyr*100 & yrmolist<=(maxyr+1)*100 & yrmolist-floor(yrmolist/100)*100==12 );
    elseif strcmp(freq,'qtrly')
        loc = find( yrmolist>=minyr*100 & yrmolist<=(maxyr+1)*100 & ismember(yrmolist-floor(yrmolist/100)*100,[3,6,9,12]) );
    else
        loc = find( yrmolist>=minyr*100 & yrmolist<=(maxyr+1)*100 );
    end    
    logPD       = pd(loc,:);
    log_ptfret  = ret(loc,:);
    log_ptfd    = divgr(loc,:);
    ptfsize     = ptfsize(loc,:);

    logPD(isnan(logPD) | isinf(logPD))                = nan;
    log_ptfret(isnan(log_ptfret) | isinf(log_ptfret)) = nan;
    log_ptfd(isnan(log_ptfd) | isinf(log_ptfd))       = nan;

    logPD(find(ptfsize<minsize))                      = nan;
    log_ptfret(find(ptfsize<minsize))                 = nan;
    log_ptfd(find(ptfsize<minsize))                   = nan;

else
    filename = [dataloc 'Portfolio-PDs/indiv-stock-PDs_monthly'];
    load(filename)
    if strcmp(freq,'annual')
        loc = find( yrmolist>=minyr*100 & yrmolist<=(maxyr+1)*100 & yrmolist-floor(yrmolist/100)*100==12 );
    elseif strcmp(freq,'qtrly')
        loc = find( yrmolist>=minyr*100 & yrmolist<=(maxyr+1)*100 & ismember(yrmolist-floor(yrmolist/100)*100,[3,6,9,12]) );
    else
        loc = find( yrmolist>=minyr*100 & yrmolist<=(maxyr+1)*100 );
    end    
    logPD       = pd(loc,:);
    log_ptfret  = ret(loc,:);
    log_ptfd    = divgr(loc,:);
    
    logPD(isnan(logPD) | isinf(logPD))                = nan;
    log_ptfret(isnan(log_ptfret) | isinf(log_ptfret)) = nan;
    log_ptfd(isnan(log_ptfd) | isinf(log_ptfd))       = nan;

    loc         = find( sum(isnan(logPD))<=.1*size(logPD,1) & min(logPD)>1 & max(logPD)<6);
    logPD       = logPD(:,loc); 
    log_ptfret  = log_ptfret(:,loc); 
    log_ptfd    = log_ptfd(:,loc); 
end