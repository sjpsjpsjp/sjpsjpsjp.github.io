function [tm] = utl_sngl_tm_vctr_mkr( array, freq, shift );
% function [tm] = utl_sngl_tm_vctr_mkr( array, freq, shift )
% INPUTS:
%  - array :  a time array
%     if no other argument is given, uses default freq vector [12,31,24,60,60]
%  OPTIONAL
%  - freq : the frequency of the time array (how many subunits are in each time unit): a scalar or vector; if the freq
%  vector is less than 1+size(array,2), we assume the sub-er units are ignored.
%  - shift : if anything is put here, then the "shift" described below is implemented in the time vector output, and
%  only for two-dimensional time arrays
% OUTPUTS:
%  - tm : a nx1 time vector expressing the subunits as fractions of the units
%
% NOTES:
% Default operation puts the first subunit of a unit of time as equal to the unit of time: i.e. January 1970 is
% represented as 1970, Feb 1970 as 1970+(1/12), etc.
%
% "shift" shifts the tick markers so that subunits appear within the "ticks" of the units themselves; for example,
% if we are dealing with quarterly data, we'd have the entries in the time vector (and thus the ticks) appear as so:
% |____________|
% | |  |  |  | |
% y q  q  q  q y
% This is related to the default operation as follows: Jan 1970 is 1970+(1/24), Feb 1970 is 1970+(1/24)+(1/12),etc.
%

default = [12,31,24,60,60];

switch nargin
    case 1
        if size(array,2) == 1 % spit out the array given -- no need to construct anything
            tm = array;
            return
        else % build freq for use out of switch loop
            freq = default(1:size(array,2)-1);
        end
        
    case 2
        if size(array,2) == 1 % spit out the array given -- no need to construct anything
            tm = array;
            return
        else % build freq for use out of switch loop
            freq = reshape(freq,1,length(freq));
        end

    case 3
        if size(array,2) == 2
            tm = array(:,1) + (1/(2*freq(1)))*ones(size(array,1),1) + (1/freq(1))*(array(:,2) - ones(size(array,1),1));
            return
        else
            error('utl_sngl_tm_vctr_mkr was told to shift, but the array had more than two dimensions')
        end
        
    otherwise
        error('utl_sngl_tm_vctr_mkr does not know what to do -- error')     
end

if length(freq) == 1
    tm = array(:,1) + (1/freq)*(array(:,2)-1);
else
    cf = [freq(2:end) 1];
    cf = fliplr(cf);
    cf = cumprod(cf);
    cf = fliplr(cf);
    tm = [  array(:,1) + ... % add year units
            sum(  (1/prod(freq)) *  (array(:,2:1+length(freq))-1) .* repmat(cf,size(array,1),1) ,  2 )  ];
end

    