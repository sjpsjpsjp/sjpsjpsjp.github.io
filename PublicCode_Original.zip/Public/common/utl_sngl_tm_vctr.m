function [tm] = utl_sngl_tm_vctr( array, freq, shift );
% function [tm] = utl_sngl_tm_vctr( array, freq, shift )
%
%  This is just an alias for "utl_sngl_tm_vctr_mkr" -- see that documentation. It exists because I forget the "_mkr" so
%  often.
%

switch nargin
    case 1
        tm = utl_sngl_tm_vctr_mkr(array);
    case 2
        tm = utl_sngl_tm_vctr_mkr(array,freq);
    case 3
        tm = utl_sngl_tm_vctr_mkr(array,freq,shift);
end
