function [log_mktret log_pd log_d smb hml] = aggbuild(minyr,maxyr,dataloc,freq)

 %#ok<*NASGU,*NODEF>

if strcmp(freq,'annual')
    load([dataloc 'Aggregate_Mkt_Data_Annual_101102']);
    mktloc      = find(mktdatelist>=minyr & mktdatelist<=maxyr);
    load([dataloc 'FF_factors_annual']);
    ffloc       = find(ffyrlist>=minyr & ffyrlist<=maxyr);
elseif strcmp(freq,'qtrly')
    load([dataloc 'Aggregate_Mkt_Data_Qtrly_101102']);
    mktloc      = find(mktdatelist>=10*minyr & mktdatelist<=10*(maxyr+1));
end    
 
log_mktret  = mktret(mktloc);
log_d       = mktdivgr(mktloc);
log_pd      = mktpd(mktloc);
smb         = smb(ffloc); 
hml         = hml(ffloc);
clear loc ffloc



