function out = nantrailmovav(in,n,varargin)
% out = nantrailmovav(in,n,reqd)
% inputs
% in   : matrix with nans
% n    : number of trailing observations to use in moving average
% reqd : number of non-nan observations for moving average to be non-nan
% outputs
% out : matrix of trailing moving averages

if nargin <3, reqd = n-1; else reqd = varargin{1}; end
nanin      = isnan(in);
tmp        = cumsum(~nanin);
numnonnans = [ tmp(1:n,:) ; ...
               tmp(n+1:end,:) - tmp(1:end-n,:) ];
toofew     = numnonnans<reqd;
tmp2       = nancumsum(in);
out        = [ tmp2(1:n,:) ; ...
               tmp2(n+1:end,:) - tmp(1:end-n,:) ];
out( toofew(:) ) = nan;
out        = out ./ numnonnans;


