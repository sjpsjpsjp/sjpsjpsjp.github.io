function [d] = utl_tm_vctrs_dffrnc(tv1, tv2, f );
% INPUTS:
%  -  tv1   :  a 1xk time vector (e.g. [1947,7] or [1947,7,12])
%  -  tv2   :  a 1xk time vector
%  -  f  : the frequency of the time vector: how many subunits per unit of time (quarterly? monthly? etc)
%Outputs
%  -  d  : the difference tv2-tv1 in subunits; negative if tv1 is later than tv2, positive if tv2 is later than tv1,
%  zero if the two time vectors are identical, unity in absolute value is the time vectors are adjacent.
%
% Only uses the subunit of the year, leaves the subsubunit unaffected.

if ( (tv1(1,2) > f) | (tv2(1,2) > f) ); % the given frequency doesn't make sense given the subunits in the time vectors
    disp(' ');error('utl_tm_vctrs_dffrnc: One of the time vectors given has a subunit that exceeds the frequency given');
end;

if ( tv1(1,1) < tv2(1,1) ); % case where tv1 is an earlier unit of time (e.g. 1947 versus 1950)
    a = tv2(1,1)-tv1(1,1);
    b = f - tv1(1,2);
    d = b + (a-1)*f + tv2(1,2);
elseif ( tv2(1,1) < tv1(1,1) ); % case where tv2 is an earlier unit of time (e.g. 1947 versus 1950)
    a = tv1(1,1)-tv2(1,1);
    b = f - tv2(1,2);
    d = -( b + (a-1)*f + tv1(1,2) );
else; % case when tv1 and tv2 are the same unit of time (e.g. [1947,3] and [1947,8])
    d = tv2(1,2)-tv1(1,2);
end;

d;