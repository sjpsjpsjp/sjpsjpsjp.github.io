function out = utl_dmn(a)
% out = utl_dmn(a)
% inputs:
% - a : array or cell array or arrays
% outputs:
% out : demeaned array or cell array of arrays

switch iscell(a)
    case 0
        out = a-repmat(nanmean(a),size(a,1),1);
    case 1
        out = cell(size(a));
        for j=(1:length(a(:)))
            out{j} = a{j} - repmat(nanmean(a{j}),size(a{j},1),1);
        end
end