function [B] = utl_rplc_nn(A,varargin);
% [B] = utl_rplc_nn(A,value);
% inputs
% - A : matrix
% - value : value to replace NaNs with (optional); if 'mean', then replaces with column mean
% outputs
% - B : matrix with no NaNs
%
%Utility to Replace NaNs
% 
% utl_rplc_nn replaces every element of a matrix A that has the entry "NaN" with "0" by default, or <value> if given

B = A;
if nargin > 1
    value = varargin{1};
    altway = 0;
    if strmatch(value,'mean')
        altway = 1;
        value = repmat(nanmean(A),size(A,1),1);
    end 
else
    value = 0;
    altway = 0;
end

switch altway
    case 0
        B(isnan(A(:))) = value;
    case 1
        B(isnan(A(:))) = value(isnan(A(:)));
end
