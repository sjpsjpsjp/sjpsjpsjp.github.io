% cpfactor.m
% relabeled Excess Bond Return Construction and Cochrane Piazzesi Factor.m

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Startup Always
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


who_are_you = 'seth';

if strcmp(who_are_you,'seth')
    directory = 'd:/sjp/kellypruitt/';    
elseif strcmp(who_are_you,'bryan')
    directory = '/Users/bkelly0/Work/Economics/Research/';
end

texloc  = [directory 'Disagg_Val_Ratio2/Tex/Results/'];
plotloc = [directory 'Disagg_Val_Ratio2/Tex/Figures/'];
dataloc = [directory 'Disagg_Val_Ratio2/Data/'];
codeloc = [directory 'Disagg_Val_Ratio2/Code/common'];

cd( codeloc )
    
%#ok<*PRTCAL,*ALIGN>

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Construct Excess Bond Returns (see Cochrane-Piazzesi AER 2005)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[dates P1 P2 P3 P4 P5] = textread([dataloc 'fama_bliss_1_to_5.txt'],'%n%n%n%n%n%n','headerlines',1 );


p1 = log(P1/100);
p2 = log(P2/100);
p3 = log(P3/100);
p4 = log(P4/100);
p5 = log(P5/100);

f2 = p1-p2;
f3 = p2-p3;
f4 = p3-p4;
f5 = p4-p5;

dates = dates(13:end);

% These are lagged by one year, so time t
y1 = -p1(1:end-12);
f2 = f2(1:end-12);
f3 = f3(1:end-12);
f4 = f4(1:end-12);
f5 = f5(1:end-12);

% These are NOT lagged by one year, so time t+1
r2 = p1(13:end)-p2(1:end-12);
r3 = p2(13:end)-p3(1:end-12);
r4 = p3(13:end)-p4(1:end-12);
r5 = p4(13:end)-p5(1:end-12);

rx2 = r2 - y1;
rx3 = r3 - y1;
rx4 = r4 - y1;
rx5 = r5 - y1;

excel = [dates rx2 rx3 rx4 rx5 y1 f2 f3 f4 f5];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Construct C.P. Factor (see Cochrane-Piazzesi AER 2005)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

rxbar = nanmean( [rx2 rx3 rx4 rx5] , 2 );

gamma = regress( rxbar, [ones(size(rxbar)) y1 f2 f3 f4 f5] );

CP = [ones(size(rx2)) y1 f2 f3 f4 f5]*gamma;

% Check that b_n matches with CP paper (b2~.47, b3~.87, b4~1.24, b5~1.43)
b2 = regress( rx2, CP );
b3 = regress( rx3, CP );
b4 = regress( rx4, CP );
b5 = regress( rx5, CP );

scale = sum( [b2 b3 b4 b5] )/4;
b2 = b2/scale;
b3 = b3/scale;
b4 = b4/scale;
b5 = b5/scale;




