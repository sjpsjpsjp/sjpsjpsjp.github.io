function t = utl_fnd(a,b)
% wherefound = utl_fnd(findthis,wheretolook)
% wherefound = utl_fnd(wheretolook,findthis)
% inputs:
% - findthis : time vector 1 x k
% - wheretolook : time array n x k
% outputs:
% - wherefound : array of indices where this is found; empty if nothing is found
%
% NOTE: the time array <wheretolook> and the time to be found <findthis> can be entered as either arg to avoid silly mistakes

% Seth Pruitt, 20090819

aa = size(a,1);  bb = size(b,1);
if aa < bb
    wtl = b;
    ft = a;
elseif bb < aa
    wtl = a;
    ft = b;
else
    disp(['utl_fnd does not know which arg is <findthis> and which is <wheretolook>: the sizes are ' num2str(aa) ...
        ' and ' num2str(bb)])
    wtl = b;
    ft = a;
end

t = find(ismember(wtl,ft,'rows'));