function z = lead(x,n,v)
% PURPOSE: creates a matrix or vector of lead values
% -------------------------------------------------------
% USAGE: z = lead(x,n,v)
% where: x = input matrix or vector, (nobs x k)
%        n = order of lead
%        v = (optional) replacement values (default=0)
% ------------------------------------------------------
% RETURNS: z = matrix (or vector) of leads (nobs x k)
% ------------------------------------------------------
% NOTES: if n <= 0, z = [] is returned. While you may find this
%        preverse, it is sometimes useful.
%-------------------------------------------------------
% SEE ALSO: mlag() 
%-------------------------------------------------------

% written by:
% Bryan Kelly


switch(nargin)

case 1
   n = 1; v = 0;
   zt = ones(n,cols(x))*v;
   z = [trimr(x,n,0) ; zt];

case 2
   v = 0;
   if n < 1
   z = [];
   else
   zt = ones(n,cols(x))*v;
   z = [ trimr(x,n,0) ; zt];
   end

case 3
   if n < 1
   z = [];
   else
   zt = ones(n,cols(x))*v;
   z = [ trimr(x,n,0) ; zt];
   end

otherwise
error('lag: wrong # of input arguments');
end;

  
