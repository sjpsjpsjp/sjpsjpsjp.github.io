function [y,M] = utl_mvng_avrg(x,k,p)
% function [y,M] = utl_mvng_avrg(x,k,p)
% INPUTS:
%  -  x : data matrix
%  -  k : a scalar argument in MA(k) (made positive by default)
%  -  p : place to put moving average -- one of the following strings
%     OPTIONS:
%       - 'l' -- leading (average at time t composed of time t value plus k-1 past values)
%       - 'c' -- center (avg at time t composed of time t value plus (k-1)/2 past values and (k-1)/2 future values); default
%       is to include one more past value than future if given even number (so that (k-1) is odd))
%       - 'f' -- forward (avg at time t composed of time t value plus k-1 future values)
% OUTPUTS:
%  -  y : data matrix, same size as x, moving average lined up with x
%  -  M : ones matrix (sparse) used to construct moving average
%

[r,c] = size(x);
k=abs(k); % make positive
if k >= r
    error('utl_mvng_avrg was passed a "k" bigger than the number of rows in data "x"')
end

if ( round(k/2) == k/2 ) % r is even
    even = 1;
else
    even = 0;
end

okstrings = {'l','c','f'};
w = strmatch(lower(p),okstrings);
if isempty(w)
    warning(['utl_mvng_avrg passed an unrecognized place: "' lower(p) '" ; using the leading place by default']);
end

switch lower(p)
    case 'l'
        d = [-(k-1):0];
    case 'c'
        switch even
            case 0
                d = [-(k-1)/2:(k-1)/2];
            case 1
                d = [floor(-(k-1)/2):floor( (k-1)/2 )];
        end
    case 'f'
        d = [0:k-1];
    otherwise
        d = [-(k-1):0];
end

M = zeros(r);
for i=d
    M = utl_dgnl_rplc( M  ,  i  ,  ones( r-abs(i), 1) );
end
if p == 'l' || p == 'c'
    M(1:abs(d(1)),:) = 0;
end
if p == 'f' || p == 'c'
    M(end-d(end)+1:end,:) = 0;
end
M = sparse(M);

y=NaN(size(x));
for i=(1:c);
    y(:,i) = (1/k)*M*x(:,i);
    if p == 'l' || p == 'c'
        y(1:abs(d(1)),i) = NaN;
    end
    if p == 'f' || p == 'c'
        y(end-d(end)+1:end,i) = NaN;
    end
end
    
    
