function [B,s] = utl_nrmlz_mtrx_bsrvd(A,sampmean,sampvariance);
% Utility to Normalize a Matrix with both missing and Observed entries
%Inputs:
%   - A : a matrix which might have NaN entries, denoting missing obserations; assumes that
%   variables exist as columns, so that the normalization is for each column
%   - sampmean : a scalar value that is the desired sample mean for each column: if none, default is 0
%   - sampvariance : a scalar value that is the desired sample variance for each column; if not, default is 1
%Outputs:
%   - B : the standardized matrix with NaN where they appeared before if there
%   are no errors, and the original data if there are errors encountered
%   - s : a structure with .mean giving the mean and .variance giving the variance
%
% Uses nanmean and nanvar

mn = 0;
va = 1;
if nargin > 1
    mn = sampmean;
    if nargin > 2
        va = sampvariance;
    end
end

s.mean = nanmean(A);
s.variance = nanvar(A);

B = (A - repmat(s.mean,size(A,1),1)) ./ repmat(sqrt(s.variance),size(A,1),1);
B = sqrt(va)*B + mn;
