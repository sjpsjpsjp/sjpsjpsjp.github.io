function cov = utl_HAC(data,band,method,varargin)
%  cov = utl_HAC(data,band,method)
%  cov = utl_HAC(data,band,method,verbose)
%  inputs  :
%  -  data  :  T x k matrix, with vars in cols
%  -  band  :  bandwidth or truncation parameter; or 'auto' to use automatic bandwidth
%  -  method  :  string with choice of HAC method -- programmed options are now
%      - 'neweywest1987'
%      - 'gallant1987'
%      - 'andrews1991'
%  -  verbose  :  any fourth argument causes automatic bandwidth to be displayed
%  outputs  :
%  -  cov  :  spectral density at freq zero
%
% Follows Hamilton (1994) discussion.  Uses Andrews (1991) automatic bandwidths
%
% Choices are now 'neweywest1987', 'gallant1987', 'andrews1991'

[T,k] = size(data);

if isstr(band) & nargin > 3
    verbose = 1;
else
    verbose = 0;
end

if isstr(band) % check for string (any) [code adopted from Bruce Hansen's URREG.m]
    eb=data(1:T-1,:);
    ef=data(2:T,:);
    ae=sum(eb.*ef)'./sum(eb.^2)';
    ee=ef-eb.*(ones(length(eb(:,1)),1)*ae');
    se=mean(ee.^2)';
    temp=(1-ae).^2;
    ad=sum((se./((1-ae).^2)).^2)';
    aese=ae.*se;
    a1=4*sum((aese./((((1-ae).^3).*(1+ae))*ones(1,length(aese(1,:))))).^2)'/ad;
    a2=4*sum((aese./(((1-ae).^4)*ones(1,length(aese(1,:))))).^2)'/ad;
    switch lower(method)
        case {'neweywest1987'}
            band = 1.1447*((a1*T)^.333);
            if band>(T-2)
                band=T-2;
            end
        case {'gallant1987'}
            band = 2.6614*((a2*T)^.2);
            if band>(T-2)
                band=T-2;
            end
        case {'andrews1991'}
            band = 1.3221*((a2*T)^.2);
    end
end

if verbose
    disp(['utl_HAC using ' method ' automatically selected bandwith ' num2str(band)])
end

switch lower(method)
    case {'neweywest1987'}
        Gc = Gest(data,band);
        cov = Gc{1};
        for v=(1:ceil(band))
            cov = cov  +  ( 1 - v/(band) ) * ( Gc{v+1} + Gc{v+1}' );
        end
        
    case {'gallant1987'}
        Gc = Gest(data,band);
        cov = Gc{1};
        for v=(1:ceil(band))
            cov = cov  +  Galkern(v/(band)) * ( Gc{v+1} + Gc{v+1}' );
        end
        
        
    case {'andrews1991'}
        Gc = Gest(data,T-1);
        cov = Gc{1};
        for v=(1:T-1)
            cov = cov  +  GSkern(v/(band)) * ( Gc{v+1} + Gc{v+1}' );
        end
        cov = T/(T-k)*cov;
        
end


    function Gc = Gest(Y,q)
        for v=(0:q)
            Gc{v+1} = (1/T) * data(1+v:end,:)' * data(1:end-v,:);
        end
    end
    function k = Galkern(z)
        if (z >= 0) & (z <= 0.5)
            k = 1 - 6*z^2 + 6*z^3;
        elseif (z > 0.5) & (z < 1)
            k = 2*(1-z)^3;
        else
            k = 0;
        end
    end
    function k = QSkern(z)
        k = (25/12/pi^2/z^2)*(sin(6*pi*z/5)/6/pi/z*5-cos(6*pi*z/5));
    end

end

