function [F,L,chosenr,crit,predX,fighan] = utl_sw02_prncpl_cmpnnts_fctr_stmtr(X,varargin)
% [F,L,chosenr,crit,predX,fighan] = utl_sw02_prncpl_cmpnnts_fctr_stmtr(X)
% [F,L,chosenr,crit,predX,fighan] = utl_sw02_prncpl_cmpnnts_fctr_stmtr(X,varargs)
% inputs 
% - X : data array 
% - varargs : any of the following combos
%     + 'numfac' : scalar -- either the number of factors found, or max tested for (default is 1) +
%     'test' : 'on' or 'off', determines if test is used to determine number of factors (default is
%     'off') 
%     + 'testname' : string indicating what test or criterion to use, of the following options
%     (default 'baing2002_icp2'):
%         -
%         'baing2002_icp1','baing2002_icp2','baing2002_icp3','baing2002_pcp1','baing2002_pcp2','bain
%         g2002_pcp3','onatski 2009_estimator'
%     + 'convgraph' : 'on' or 'off', determines if EM convergence graph is shown (default is 'off')
%     + 'standardize' : 'on' or 'off', determines if passed <X> is standardized here (when 'on') or
%     untreated (when 'off') -- note data always demeaned (default 'off') 
%     + 'maxEMit' : scalar -- number of EM iterations to try (default 1e4)
%     + 'missdatatol' : scalar -- threshold for EM covergence (default 1e-3) 
%     + 'missdatazerotol' : scalar -- threshold for dividing by zero to find convergence (default
%     1e-4)
%     + 'prevFandL' : structure with ".F" and ".L" matrices, ".F" has the same row dimension as X,
%     ".L" has the same column dimension as X, and these are used to calculate the first guess for
%     an EM algorithm
%     + 'dispintmsg' : 'on' or 'off', determines if EM convergence messages are shown and test
%     criteria values are shown (default is 'off') 
%     + 'dispinterval' : scalar -- number of EM iterations to display info in command window
%     (default 100) 
%     + 'screeplot' : 'on' or 'off' displays screeplot of largest non-missing part of data (default
%     'off')
% outputs 
% - F : factors 
% - L : factor loadings 
% - chosenr : number of factors chosen by given test/criteria, if <r> is recognized string 
% - crit : objective value if no test; value of test/criteria for specified <chosenr> if test; Inf
% if no convergence 
% - predX : predicted X (based on factors); if a given number of factors yields no convergence, is
% the minimum relative tolerance found in the EM algorithm 
% - fighan : figure handle of convergence figure -- if not called for, then figure is closed upon
% convergence
%
% Follows Stock Watson JASA (2002) and JBES (2002)
%

% Author: Seth Pruitt; 1st vers: 2005.5.1; current vers: 2011.5.12

% % Persistents -- useful if utl_sw02_... is embedded in another loop, to save time and memory
% persistent availabletc complicated testname test convgraph standardize numfac missdatatol
% missdatazerotol maxEMit persistent dispintmsg dispinterval screeplot okargs pname pval j k kk T n
% normfactors jnk bal whereXisbad whereXisgood persistent Xprop Xmeans rs Lprop Fprop Lprev Fprev
% tol1 tol

% Available tests/criteria (programmed at bottom)
availabletc = {'baing2002_icp1','baing2002_icp2','baing2002_icp3','baing2002_pcp1','baing2002_pcp2','baing2002_pcp3',...
    'onatski2009_estimator'};
complicated = availabletc(end);% complicated choice procedure before EM

% Defaults
testname = @baing2002_icp2;
crit = 'baing2002_icp2';
test = 0;
convgraph = 0;
standardize = 0;
numfac = 1;
missdatatol = 1e-3;
missdatazerotol = 1e-4;
maxEMit = 1e4;
dispintmsg = 0;
dispinterval = 100;
screeplot = 0;
prevFandL = nan;
% look for passed varargs
if (rem(nargin,2) == 0 || nargin < 1)
    error('utl_sw02_prncpl_cmpnnts_fctr_stmtr: Incorrect number of arguments ');
end
okargs = {'numfac','maxEMit','missdatatol','missdatazerotol','dispinterval',...
    'test','convgraph','standardize','dispintmsg','screeplot',...
    'testname','prevFandL'};
for j=1:2:(nargin-2)
    pname = varargin{j};
    pval = varargin{j+1};
    k = strmatch(pname,okargs,'exact');
    if isempty(k)
        error(['utl_sw02_prncpl_cmpnnts_fctr_stmtr: Unknown parameter name: ' pname]);
    elseif length(k)>1
        error(['utl_sw02_prncpl_cmpnnts_fctr_stmtr: Ambiguous parameter name: ' pname]);
    else
        switch k
            case {1,2,3,4,5,12}
                eval([pname '= pval;']);
            case {6,7,8,9,10}
                kk = strmatch(lower(pval),{'off','on'});
                if isempty(kk)
                    disp(['utl_sw02_prncpl_cmpnnts_fct_stmtr was passed ambiguous on/off flag:' pval ' -- default kept']);
                else
                    eval([pname '=kk-1;']);
                end
            case 11
                kk = strmatch(pval,availabletc,'exact');
                if isempty(kk)
                    disp(['utl_sw02_prncpl_cmpnnts_fct_stmtr was passed ambiguous testname:' pval ' -- default kept'])
                else
                    eval([pname '=@' pval ';']); % test criterion function handle is now assigned to <testname>
                    crit = pval;
                end
        end
    end
end

% Preliminaries
[T,n] = size(X);

% Standardize if called
if standardize
    [X,normfactors] = utl_nrmlz_mtrx_bsrvd(X);
end

% Look for complicated testing
if strmatch(crit,complicated)
    complicated = 1;
else
    complicated = 0;
end

% check for missing data
if sum(sum(isnan(X))) > 0
    missing = 1;
else
    missing = 0;
end

% find a balanced subset (for screeplot command, or testing using complicated procedure that requires it)
if screeplot | complicated
    jnk.x = X;jnk.t = [1:size(X,1)]';
    bal = utl_blnc_ts_strctr(jnk);
end
% screeplot if called
if screeplot
    jnk3 = flipud(sort(eig( (1/T)*bal.x'*bal.x )));
    plot([1:length(jnk3)]',jnk3,'ks',[1:length(jnk3)]',jnk3,'k-');
    hold on
    title('Scree plot of largest balanced subset of data')
    ylabel('value')
    xlabel('eigenvalue')
    textbp(['from ' num2str(size(bal.x,1),'%0.0f') ' of ' num2str(size(X,1),'%0.0f') ' obs'])
    hold off
end
clear jnk*
    


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Program
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Initial check and prep for EM algorithm

% look for bads (missings or nonsensical values)
X(isinf(X(:))) = nan;
whereXisbad = isnan(X(:));
whereXisgood = ~whereXisbad;
% demean if not done by standardization above
Xmeans = nanmean(X); % this is always used by predX below
if ~standardize
    Xprop1 = bsxfun(@minus,X,Xmeans);
else
    Xprop1 = X;
end
% Xprop1 is the data we work with

% If we have missing data, we initialize our Xprop1 data in one of two ways: (1) if there are no
% good rows (with no nans and no infs) we fill all the bad observations with zero; (2) if there are
% some good rows we estimate pcs/loadings on the good rows and use these and least-squares to fill
% in bad values
if max(whereXisbad)>0
    notnanX = ~isnan(X);
    goodrows = sum( notnanX, 2)==size(X,2);
    if sum(goodrows) < 2 % not enough for initial pc estimate
        Xprop1(whereXisbad) = 0;
    else % estimate pcs on observed rows, use LS to fill initial guess
        [Li Fi] = princomp(Xprop1(goodrows,:) , 'econ' );
        % the least-squares estimate of F is given by (L'L)\(L'X) for each period.  But we need to
        % do this in a loop since whenever X has bads, we should ignore those elements of L, which
        % means (L'L) is not identical for all time periods (even if we zeroed out bads in X and so
        % (L'X) was okay where X is N x tau for tau the number of bad time periods
        for tau=find(~goodrows)'
            goods = notnanX(tau,:);
            try
            f     = (Li(goods,1:numfac)'*Li(goods,1:numfac))\(Li(goods,1:numfac)'*Xprop1(tau,goods)');
            catch
                keyboard
            end
            Xprop1(tau,~goods) = ...
                Li(~goods,1:numfac)*f;
        end
    end
end



if test & ~complicated% loop of r to consider -- degenerate if <test> = 0
    rs = 1:numfac;
    L = cell(numfac,1); F = cell(numfac,1); tc = zeros(numfac,1);
elseif test & complicated
    % determine factors from balanced subset
    rs = testname(NaN,bal.x,NaN,NaN,numfac);
    L = []; F = []; tc = [];
else
    rs = numfac;
    L = []; F = []; tc = [];
end
                                                                                                        
% calculate loadings and factors for considered r (could be just one r)
for i = rs
    tic
    if dispintmsg
    disp(['***                                     *****                                             ****'])
    disp(['***                                                                                       ****'])
    disp(['***    Started principal components estimator (for ' num2str(i) ' factors) at ' datestr(clock) ])
    disp(['***                                                                                       ****'])
    end
    
    % eigenvector estimate of L; or initial iteration of eigenvector estimate of L for missing data case
    [Lprop,Fprop] = princomp( Xprop1 , 'econ' );
    Lprop         = Lprop(:,1:i);
    Fprop         = Fprop(:,1:i);
    %[fhat jnk] = svd(Xprop1*Xprop1'); %for semi-def symmetric matrix, same as eig value decomposition but sorts in descending order
    %Fprop      = fhat(:,1:i)*sqrt(T);
    %Lprop      = Xprop1'*Fprop/T;
    
    if missing % set tolerance to zero if no missing to avoid EM loop
        tol = 1;
        runningtol = 1;
    else
        tol = 0;
    end

    if test && dispintmsg %display info about <i> loop if the loop is nondegenerate, and if <dispintmsg> is on
        disp(['** We looking for ' num2str(i) ' PCs; we are considering up to ' num2str(numfac) ' PCs using test/crit ' crit])
        disp(['** The time is ' datestr(clock)])
        
    end
    
    
    if convgraph && tol == 1 %user chose to convergence-graph, and there is need for EM (missing data)
        graphtol = NaN(1000,1); fighan = figure;
    end
    it = 0;
    while tol >= missdatatol && it < maxEMit && max(whereXisbad)>0
        it=it+1;
        if isnan(prevFandL) % no initials were passed
            Lprev = Lprop; Fprev = Fprop;
        else
            Lprev = prevFandL.L; Fprev = prevFandL.F;
        end
        Xprop = Fprev*Lprev';
        Xprop(whereXisgood) = X(whereXisgood);
        [Lprop,Fprop] = princomp( Xprop , 'econ' );
        Lprop         = Lprop(:,1:i);
        Fprop         = Fprop(:,1:i);
        %[fhat jnk] = svd(Xprop*Xprop'); %for semi-def symmetric matrix, same as eig value decomposition but sorts in descending order
        %Fprop      = fhat(:,1:i)*sqrt(T);
        %Lprop      = Xprop'*Fprop/T;
        tol1( abs(Fprev(:))>missdatazerotol ) = abs( Fprop(abs(Fprev(:))>missdatazerotol) - Fprev(abs(Fprev(:))>missdatazerotol) ) ...
            ./ abs(Fprev(abs(Fprev(:))>missdatazerotol)) ;
        tol1( abs(Fprev(:))<=missdatazerotol ) = abs( Fprop(abs(Fprev(:))<=missdatazerotol) - Fprev(abs(Fprev(:))<=missdatazerotol) ) ...
            ./ missdatazerotol ;
        tol = max(max(tol1));
        if dispintmsg && (floor(it/dispinterval) == it/dispinterval)
            runningtol = min(runningtol,tol);
            disp([' EM of ' num2str(it) ' iterations at ' ...
                datestr(clock) '; tol is ' num2str(tol) ...
                ', min reltol reached is ' num2str(runningtol/missdatatol) ...
                ', maxtol is ' num2str(missdatatol) ...
                ', maxEMit is ' num2str(maxEMit) ])
        end
        if convgraph
            graphtol = [graphtol(2:end); tol/missdatatol];
            runningtol = min(runningtol,tol);
            loglog( [-999:0]' , graphtol )
            title(['Convergence is reached at reltol=1 (abstol=' num2str(missdatatol) ') -- we are finding ' num2str(i) ' PCs'])
            xlabel(['Last 1000 iterations - min reltol reached so far is ' num2str(runningtol/missdatatol)])
            ylabel('Current tol relative to maxtol')
            drawnow
        end
    end
    if it == maxEMit && dispintmsg
        disp('WE REACHED MAXIMUM NUMBER OF ITERATIONS')
    elseif dispintmsg
        disp(['EM converged at iteration ' num2str(it)])
    end
    
    Xprop = Fprop*Lprop';
    
    
    if test & ~complicated
        L{i} = Lprop;
        F{i} = Fprop;
        tc(i) = testname(X,Xprop,T,n,i);
        if dispintmsg
        disp(['For ' num2str(i) ' PCs the ' crit ' test/crit value is ' num2str(tc(i))])
        end
    else
        L = Lprop;
        F = Fprop;
        tc = numfac;
    end
    
    if it == maxEMit
        tc(i) = Inf;
    end
    
end

if test & ~complicated
    [crit,chosenr] = min(tc);
    L = L{chosenr};
    F = F{chosenr};
else
    chosenr = rs;
    crit = tc;
end

if nargout >= 5 % predX was called -- we need to un-normalize if we did
    predX = F*L' + Xmeans; %normalized predX
    if standardize
        predX = predX .* repmat(sqrt(normfactors.variance),T,1) + repmat(normfactors.mean,T,1);
    end
end
    

if nargout < 6 && convgraph && missing % no fig handle called, but figure made -- close figure
    close(fighan)
elseif ~convgraph % no figure made -- fig handle is empty regardless of whether or not called
    fighan = [];
end

if dispintmsg
toc
end

end


function out = objV(y,yh)
% inputs
% - y : actuals
% - yh : predicted
% outputs
% - out : objective fcn value, sum of squared residuals
out = mean( nanmean(  (y-yh).^2 ) );
end

function out = baing2002_icp1(y,yh,T,n,r)
% inputs
% - y : actuals
% - yh : predicted
% - T : number of time periods; row dimension of X
% - n : number of variables; col dimension of X
% - r : number of factors;
% outputs
% - out : value of Bai-Ng (2002) ICp1 info criterion
out = log( objV(y,yh) ) + r * ((n + T) / (n*T)) * log( (n*T)/(n+T) );
end

function out = baing2002_icp2(y,yh,T,n,r)
% inputs
% - y : actuals
% - yh : predicted
% - T : number of time periods; row dimension of X
% - n : number of variables; col dimension of X
% - r : number of factors;
% outputs
% - out : value of Bai-Ng (2002) ICp2 info criterion
out = log( objV(y,yh) ) + r * ((n + T) / (n*T)) * log( min(n,T) );
end

function out = baing2002_icp3(y,yh,T,n,r)
% inputs
% - y : actuals
% - yh : predicted
% - T : number of time periods; row dimension of X
% - n : number of variables; col dimension of X
% - r : number of factors;
% outputs
% - out : value of Bai-Ng (2002) ICp3 info criterion
out = log( objV(y,yh) ) + r * log( min(n,T) ) / min(n,T);
end

function out = baing2002_pcp1(y,yh,T,n,r)
% inputs
% - y : actuals
% - yh : predicted
% - T : number of time periods; row dimension of X
% - n : number of variables; col dimension of X
% - r : number of factors;
% outputs
% - out : value of Bai-Ng (2002) PCp1 info criterion
val = sum(  sum(  utl_rplc_nn( (yh-y).^2 , 0 )  )  );
out = objV(y,yh) + r * objV(y,yh) * ((n + T) / (n*T)) * log( (n*T)/(n+T) );
end

function out = baing2002_pcp2(y,yh,T,n,r)
% inputs
% - y : actuals
% - yh : predicted
% - T : number of time periods; row dimension of X
% - n : number of variables; col dimension of X
% - r : number of factors;
% outputs
% - out : value of Bai-Ng (2002) PCp2 info criterion
val = sum(  sum(  utl_rplc_nn( (yh-y).^2 , 0 )  )  );
out = objV(y,yh) + r * objV(y,yh) * ((n + T) / (n*T)) * log( min(n,T) );
end

function out = baing2002_pcp3(y,yh,T,n,r)
% inputs
% - y : actuals
% - yh : predicted
% - T : number of time periods; row dimension of X
% - n : number of variables; col dimension of X
% - r : number of factors;
% outputs
% - out : value of Bai-Ng (2002) PCp3 info criterion
val = sum(  sum(  utl_rplc_nn( (yh-y).^2 , 0 )  )  );
out = objV(y,yh) + r * objV(y,yh) * log( min(n,T) ) / min(n,T);
end

function out = onatski2009_estimator(y,yh,T,n,r)
% inputs
% - y : actuals -- UNUSED
% - yh : predicted
% - T : number of time periods; row dimension of X -- UNUSED
% - n : number of variables; col dimension of X -- UNUSED
% - r : number of factors;
% outputs
% - out : value of Onatski (2009) factor number estimator
out = onatski(yh,r);
end

function out=onatski(X,rmax)
% This function implements the consistent procedure
% for the determination of the number of factors described
% in the paper "Determining the number of factors from empirical
% distribution of eigenvalues"
%
% The inputs are: 
% 1) an n by T matrix X, which has the factor structure X=LF'+e
% 2) rmax, which is a priori maximal number of factors

% The output is the number of factors

N=size(X,1);
T=size(X,2);

% compute the sample covariance matrix
if N<=T
    S=X*X'/T;
    minNT=N;
else
    S=X'*X/N;
    minNT=T;
end

% check that rmax is smaller enough than the sample size
if minNT<rmax+5
    disp('onatski: decrease rmax')
    out = Inf;
    return
end

% Step 1: 
% compute the eigenvalues of the sample covariance matrix and set j=rmax+1
[V,D]=eig(S);
D=diag(D);
[Ds,Ns]=sort(D);
D=flipdim(Ds,1);
j=rmax+1;

% Step 2:
% compute the slope beta in the regression of D(j)...D(j+4) on the constant
% and (j-1)^(2/3)...(j+3)^(2/3). Set delta=2*abs(beta)
depen=D(j:j+4,1);
indepen=[ones(5,1) (((j-1):1:(j+3)).^(2/3))'];
beta=inv(indepen'*indepen)*indepen'*depen;
delta=2*abs(beta(2,1));

% Step 3:
% compute r=max{i<=rmax s.t. D(i)-D(i+1)>=delta} or if all the differences
% are smaller than delta, set r=0. Set j=r+1. 
dif=D(1:rmax)-D(2:rmax+1);
detec=flipdim(dif<delta,1);
[nozero,zeroloc]=min(detec);
if nozero==1
    r=0;
else
    r=rmax+1-zeroloc;
end
j=r+1;

% Iterate Steps 2 and 3 several times (here 4)
for iter=1:4
    depen=D(j:j+4,1);
    indepen=[ones(5,1) (((j-1):1:(j+3)).^(2/3))'];
    beta=inv(indepen'*indepen)*indepen'*depen;
    delta=2*abs(beta(2,1));
    detec=flipdim(dif<delta,1);
    [nozero,zeroloc]=min(detec);
    if nozero==1
        r=0;
    else
        r=rmax+1-zeroloc;
    end
    j=r+1;
end
out=r;
end



        

