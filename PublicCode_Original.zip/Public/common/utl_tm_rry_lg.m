function L = utl_tm_rry_lg(T,varargin)
% L = utl_tm_rry_lg(T,lags)
% L = utl_tm_rry_lg(T,freq,lags)
%   inputs
%   -   T   :   a n by k time array
%   -   freq    :   (optional) a k-1 dim vector giving the frequency of the subunits of years (uses
%   default freq vector if not given)
%   -   lags    :   a vector giving the units to lag
%       - negative values go back in time, positive values go forward
%       - if the dim of <lags> is less than k, the remaining values are ignored and passed
%   outputs
%   -   L   :   the n by k lagged time array
%
%   The default freq vector is [12,31,24,60,60] and is used when only two args are passed.

def = [12;31;24;60;60];

if nargin == 2
    lags = varargin{1};
    % DEFAULT freq vector
    l = length(lags);
    freq = def(1:l-1);
else
    freq = varargin{1};
    lags = varargin{2};
    l = length(lags);
    if l>length(freq)
        freq = [freq(:); def(length(freq)+1:l)];
    end
    freq = freq(1:end-1);
end

[n,k] = size(T);
Tdeal = T(:,1:l);
if l<k
    Tignore = T(:,l+1:end);
else
    Tignore = [];
end

d = [1; cumprod(freq(:))];
T1 = Tdeal - repmat([0 ones(1,l-1)],n,1);
T2 = T1 ./ repmat(d',n,1);
T3 = sum(T2,2);

lg = lags(:) ./ d;
lg1 = sum(lg);

T4 = T3 + lg1;

Lp=NaN(n,l);
left = T4;
for k1 = (1:l)
    if k1 < l
        Lp(:,k1) = floor(left);
        left = left-Lp(:,k1);
        left = left*freq(k1);
    else
        Lp(:,k1) = round(left);    
    end
end

Lp = Lp + repmat([0 ones(1,l-1)],n,1);
L = [Lp Tignore];

    
