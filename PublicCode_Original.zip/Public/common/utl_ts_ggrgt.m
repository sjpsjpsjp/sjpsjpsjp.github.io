function out = utl_ts_ggrgt(in,fc,m)
% out = utl_ts_ggrgt(in,freqconv,method)
% inputs
% -  in :  input ts structure
% -  freqconv :  frequency conversion string
% -  method :  method of aggregation string, from one of following (when only NaN in time period, returns NaN)
%    OPTIONS - mean
%            - median
%            - last
%            - first
%            - midpoint
% outputs
%
% 
% OK freqconv:
%  - 'dm' (daily to monthly)
%  - 'mq' (monthly to quarterly)


switch lower(m)
    case {'mean','mea'}
        meth = @nanmean;
    case {'median','med'}
        meth = @nanmedian;
    case {'last','l'}
        meth = @nanlast; % defined below
    case {'first','f'}
        meth = @nanfirst; % defined below
    case {'midpoint','mid'}
        meth = @nanmidpoint; % defined below
    case {'max','maxiumum'}
        meth = @nanmax; % defined below
    case {'min','minimum'}
        meth = @nanmin; % defined below
    otherwise
        meth = @nanmean;
        warning('utl_ts_ggrgt was passed unrecognized method: mean is used by default')
end

fcok = {'dm','mq'};
k = strmatch(fc,fcok);
if isempty(k)
    error(['utl_ts_ggrgt was passed an unrecognized freq conversion string: "' fc '"'])
else
    switch k
        
        
        case 1 % daily to monthly
            [t,jnk,u] = unique(in.t(:,1:2),'rows');
            out.t = t;
            out.x = NaN(size(out.t,1),size(in.x,2));
            for j = (1:size(out.t,1))
                for jj=(1:size(out.x,2))
                    out.x(j,jj) = meth( in.x( logical( u == j ) , jj ) );
                end
            end
            
            
        case 2 % monthly to quarterly
            intq = [ in.t(:,1)  floor( (in.t(:,2)-1)/3 )+1 ];% convert the second col from months to quarter
            [t,jnk,u] = unique(intq,'rows');
            out.t = t;
            out.x = nan(size(out.t,1),size(in.x,2));
            for j = (1:size(out.t,1))
                for jj=(1:size(out.x,2))
                    out.x(j,jj) = meth( in.x( logical( u == j ) , jj ) );
                end
            end
            
        otherwise
            out = in;
            disp('utl_ts_ggrgt was surprised by the freq conversion string and output the passed structure')
            
            
    end
end
            
            


end

function b = nanmidpoint(a)
c = ~isnan(a);
b = NaN(1,size(a,2));
for i=(1:size(a,2))
    if sum(c(:,i)) ~= 0
        d = sum(c(:,i));
        d = floor(d/2);
        e = find(c);
        b(i) = a( e(d) , i );
    end
end
end

function b = nanlast(a)
c = ~isnan(a);
b = NaN(1,size(a,2));
for i=(1:size(a,2))
    if sum(c(:,i)) ~= 0
        b(i) = a( find(c,1,'last'), i );
    end
end
end

function b = nanfirst(a)
c = ~isnan(a);
b = NaN(1,size(a,2));
for i=(1:size(a,2))
    if sum(c(:,i)) ~= 0
        b(i) = a( find(c,1,'first'), i );
    end
end
end

function b = nanmax(a)
c = ~isnan(a);
b = NaN(1,size(a,2));
for i=(1:size(a,2))
    if sum(c(:,i)) ~= 0
        b(i) = max( a(c,i) );
    end
end
end

function b = nanmin(a)
c = ~isnan(a);
b = NaN(1,size(a,2));
for i=(1:size(a,2))
    if sum(c(:,i)) ~= 0
        b(i) = min( a(c,i) );
    end
end
end
