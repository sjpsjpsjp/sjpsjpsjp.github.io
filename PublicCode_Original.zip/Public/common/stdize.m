function out = stdize(X)

% out = stdize(X)
% Demeans X and scales it by its unconditional volatility estimate, 
% Xhat = (X - Xbar)/sigma(X)
% Works column-wise

out = (X-kron(ones(size(X,1),1),nanmean(X)))./kron(ones(size(X,1),1),nanstd(X));    