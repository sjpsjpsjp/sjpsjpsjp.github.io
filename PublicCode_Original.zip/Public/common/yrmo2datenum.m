function [ out ] = yrmo2datenum( yrmo )
% [ datenum ] = yrmo2datenum( yrmo )
% INPUTS
% - yrmo : date number like 198001 meaning January 1980
% OUTPUTS
% - datenum : Matlab's datenum vector

x = floor(yrmo/100);
y = yrmo-x*100;

out = datenum(x,y,1);


end

