function out = utl_fnd_strng_n_cllrry_strngs(ca,exp,varargin)
% out = utl_fnd_strng_n_cllrry_strngs(cellarray,expression)
% out = utl_fnd_strng_n_cllrry_strngs(cellarray,expression,caseinsensitive)
% 
% inputs
% -  cellarray : cell array of strings to look through
% -  expression : regular expression to use to look for
% -  caseinsenstive : if third arg passed, uses case insensitive regexpi.m
% outputs
% -  out : linear indices of matches
%
% Uses regexp.m or regexpi.m

if nargin == 3
    re = regexpi(ca,exp,'once');
else
    re = regexp(ca,exp,'once');
end
howmany = numel(cell2mat(re(:)));
out = nan(howmany,1);
ct = 0; found = 0;
while found < howmany
    ct=ct+1;
    if ~isempty( re{ct} )
        found = found+1;
        out(found) = ct;
    end
end