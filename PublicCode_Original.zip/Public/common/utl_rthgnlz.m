function Y = utl_rthgnlz(X,varargin)
% Y = utl_rthgnlz(X)
% inputs:
% - X : T x n data array to be orthogonalized
% outputs:
% - Y : T x n orthogonal matrix

[T n]=size(X);
mns = mean(X);
X = utl_dmn(X);

Y = nan(T,n);



for j=1:n-1
    proj            = (X(:,1:n-j)/(X(:,1:n-j)'*X(:,1:n-j)))*X(:,1:n-j)';
    Y(:,n-j+1)      = ( eye(T) - proj ) * X(:,n-j+1);
end
Y(:,1) = X(:,1);
Y = Y + ones(T,1)*mns;

% % Old Code
% if nargin>1
%     starter = varargin{1};
% else
%     starter = 1;
% end
% remains = setxor(1:n,starter);
% done    = [starter remains];
% 
% Y(:,starter) = X(:,starter);
% for j=1:length(remains)
%     proj            = X(:,done(1:j))/(X(:,done(1:j))'*X(:,done(1:j)))*X(:,done(1:j))';
%     Y(:,remains(j)) = ( eye(T) - proj ) * X(:,remains(j));
% end