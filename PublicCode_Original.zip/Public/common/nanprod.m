function b = nanprod(a)

c = find(~isnan(a));
b = prod(a(c));