function [f] = utl_NBERdates_forfillin(ax,varargin)
%  [f] = utl_NBERdates_forfillin(ax)
%  Inputs
%  -  ax :  the axis of the 2D figure
%  Outputs
%  -  f  :  structure with .x and .y matrices for "fill" command
%
%  The assumed placement of the shading is that a recession from 1950:I to 1950:III is represented by a shaded box
%  between 1950 and 1950.749999.
%
%  The usage is:
%  1. feed axis of current figure into utl_NBERdates_forfillin to get the object "f"
%  2. call a command like "fill(f.x,f.y,NBERshade,'LineStyle','none')" where NBERshade is appropriate coloring
%  (suggested value is [.8 .8 .8] which is the default gray appearing in the background of Matlab figures, and a good
%  gray)
%  3. redraw any lines that previously appeared on the figure after the "fill" command using these matrices.
%
%  Update peak and trough vectors periodically.
%
% Starts in 1945 (post war)

% Convention here is that 1945.0 is January 1945.
if nargin<2
    peak   = [1929+7/12; 1937+4/12; 1945+(1/12);  1948+10/12; 1953+6/12;  1957+7/12;  1960+3/12;  1969+11/12; 1973+10/12; 1980;       1981+6/12; ...
        1990+6/12; 2001+2/12; 2007+11/12];
    trough = [1933+2/12; 1938+5/12; 1945+9/12;    1949+9/12;  1954+4/12;  1958+3/12;  1961+1/12;  1970+10/12; 1975+2/12;  1980+6/12;  1982+10/12; ...
        1991+2/12; 2001+10/12; 2009+5/12];
else
    peak   = [1929 8; 1937 5; 1945 2; 1948 11; 1953 7; 1957 8; 1960 4; 1969 12; 1973 11; 1980 1; 1981 7; ...
        1990 7; 2001 3; 2007 12];
    trough = [1933 3; 1938 6; 1945 10; 1949 10; 1954 5; 1958 4; 1961 2; 1970 11; 1975 3; 1980 7; 1982 11; ...
        1991 3; 2001 11; 2009 6];
    peak   = datenum(peak(:,1),  peak(:,2)  , 1);
    trough = datenum(trough(:,1),trough(:,2), 1);
end

pks = peak(find( peak >= ax(1) & peak <= ax(2) ));
ths = trough(find( trough >= ax(1) & trough <= ax(2) ));

if ths(1) < pks(1)
    pks = [ax(1); pks];
end
if pks(end) > ths(end)
    ths = [ths; ax(2)];
end
if length(pks) ~= length(ths)
    error('utl_NBERdates_forfillin calculated recession start and end dates of different number')
end

f.x = zeros(4,length(pks));
f.y   =  [  ( ax(3)+(ax(4)-ax(3))/1000 ) * ones(1,length(pks))  ;...
            ( ax(3)+(ax(4)-ax(3))/1000 ) * ones(1,length(pks))  ;...
            ( ax(4)-(ax(4)-ax(3))/1000 ) * ones(1,length(pks))  ;...
            ( ax(4)-(ax(4)-ax(3))/1000 ) * ones(1,length(pks))  ];
for j=(1:length(pks))
    f.x(1,j) = pks(j);
    f.x(2,j) = ths(j);
    f.x(3,j) = ths(j);
    f.x(4,j) = pks(j);
end


