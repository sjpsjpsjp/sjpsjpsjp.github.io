%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Startup Always
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


who_are_you = 'seth';

if strcmp(who_are_you,'seth')
    directory = 'p:\sjp\kellypruitt\';    
elseif strcmp(who_are_you,'bryan')
    directory = '/Users/bkelly0/Work/Economics/Research/';
end

texloc  = [directory 'Disagg_Val_Ratio\Tex\Results\'];
plotloc = [directory 'Disagg_Val_Ratio\Tex\Figures\'];
dataloc = [directory 'Disagg_Val_Ratio\Data\'];
codeloc = [directory 'Disagg_Val_Ratio\Code\FM_Forecast'];

if strcmp(who_are_you,'bryan')
    texloc  = regexprep(texloc , '\', '/');
    plotloc = regexprep(plotloc, '\', '/');
    dataloc = regexprep(dataloc, '\', '/');
    codeloc = regexprep(codeloc, '\', '/');
end

cd( codeloc )
    
%#ok<*PRTCAL,*ALIGN>

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Select data series target (r) and cell array of predictors (mu)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

target = load([dataloc 'txtdatafiles\PRE4REtarMRactuals19462009annual6-size-BMdivfilton.txt']);
mus = { 'PRE4REtarMRpredictions19462009annual6-size-BMdivfilton.txt',...
        'PRE4REtarMRpredictions19462009annual12-size-BMdivfilton.txt',...
        'PRE4REtarMRpredictions19462009annual25-size-BMdivfilton.txt',...
        'PRE4PDREtarMRpredictions19462009annual6-size-BMdivfilton.txt',...
        'PRE4PDREtarMRpredictions19462009annual12-size-BMdivfilton.txt',...
        'PRE4PDREtarMRpredictions19462009annual25-size-BMdivfilton.txt',...
        'PRE4PDREBMtarMRpredictions19462009annual6-size-BMdivfilton.txt',...
        'PRE4PDREBMtarMRpredictions19462009annual12-size-BMdivfilton.txt',...
        'PRE4PDREBMtarMRpredictions19462009annual25-size-BMdivfilton.txt'};
    
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Loop through
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for j=1:length(mus)
    try mu = load([dataloc 'txtdatafiles\' mus{j}]);
    catch disp(['    !->  could not load ' mus{j}]); continue
    end
    r = target;
    disp(' ');disp(' ********');disp(' ');
    disp(['For mu from ' mus{j}])
    loc = ~isnan(mu+r);
    mu = mu(loc); r = r(loc);
    tmp1  =  1 - nanvar(mu-r)/nanvar(r);
    tmp2  =  1 - nanvar( [mu(mu>=0)-r(mu>=0);r(mu<0)] )/nanvar(r);
    tmp3  =  nanstd(mu);
    tmp4  =  nanstd(mu(mu>=0));
    disp([' Regular R2 is ' num2str(100*tmp1,'%2.2f') '%           Zeroed-out R2 is ' num2str(100*tmp2,'%2.2f') '%'])
    disp([' Regular vol is ' num2str(100*tmp3,'%2.2f') '%           Zeroed-out vol is ' num2str(100*tmp4,'%2.2f') '%'])
    disp(' ')
end
