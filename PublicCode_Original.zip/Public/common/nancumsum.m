function out = nancumsum(in)
a = isnan(in);
b = in;
b( a(:) ) = 0;
out = cumsum(b);