function tma = utl_tm_rry(tvs,freq,varargin)
%  tma = utl_tm_rry(tvs,freq,num)
%  tma = utl_tm_rry(tvs,freq,num,'tve')
%  tma = utl_tm_rry(tvs,freq,tve)
%  tma = utl_tm_rry(tvs,freq,tve,option)
%
%  inputs:
%  -  tvs   :  starting time vector
%  -  freq  :  freq vector upto the subunit you want to operate on (eg [12] implies you work on the
%  subunit/2nd-col and it has a frequency of 12; [12,31] implies you work on the subsubunit/3rd-col and the subunit has
%  a frequency of 12 and the subsubunit has a frequency of 31)
%  -  num   :  scalar -- if so, must be integer:
%           * positive means create time array going forward that many steps (defined by the last element of "freq")
%           * negative means create time array going backward that many steps (defined by the last element of "freq")
%        -  if a scalar "num" and the 4th arg is 'tve', tma is the "tve" vector "num" steps away from "tvs" according to
%        "freq".
%  -  tve   :  ending time vector of same length as "tvs"; if "option" is left unspecified, the default option='create'
%  -  option:  one of the following strings ('tve' option not defined if "tve" is given instead of scalar "num")
%        -  'diff'      :  number of steps between "tve" and "tvs" according to "freq" -- can be neg or pos (depending
%        on if "tve" is before or after "tvs")
%        -  'create'    :  create a time array starting with "tvs", ending with "tve", and proceeding through as many steps 
%        necessary along the subunit specified by the size of "freq" (and, of course, its value).  If there are subunits
%        ignored (ie "tvs" is [1980 1 12] and "freq" is 12), then the array "tma" has the ignored subunits of "tvs"
%        until the last row, when it has the ignored subunits of "tve".
%  outputs:
%  -  tma   :  a time array, scalar difference, or ending time vector
%        

tvs = reshape(tvs,1,length(tvs));% ensure "tvs" is row vector

if nargin < 3
    error('utl_tm_rry needs at least 3 args')
elseif nargin >= 3
    if isscalar(varargin{1})
        num = varargin{1};
        option = 'create'; % the default operation when "option" is not specified in 4th arg
        if num == 0
            tma = tvs;return % returns "tvs" if 0 was passed as "num"
        end
    elseif isnumeric(varargin{1})
        tve = varargin{1};
        option = 'create'; % the default operation when "option" is not specified in 4th arg
        if length(tve)~=length(tvs)
            error('utl_tm_rry was given a "tve" vector that is not the same length as "tvs"')
        end
    else
        error('utl_tm_rry did not recognize the third argument')
    end
    if nargin >= 4
        option = varargin{2};
        if ~ischar(option)
            error('utl_tm_rry was given a 4th argument that is not a string')
        end
    end
end

fn = length(freq);

if exist('num') == 1 % "num" exists already -- we create "tve"
    tve = tvs;
    fi = fn;
    fnum = num;
    while (fi > 0) & (fnum ~= 0) % either we've gotten to the year unit, or there is no more need to move higher subunits
        tve(fi+1) = 1 + mod( (tvs(fi+1)-1)+fnum , freq(fi) ); % the fi+1 col of "tve" is set to the correct time array value
        fnum_new =  floor(   (tvs(fi+1)-1+fnum) / (freq(fi))  );% the new fnum -- how many of the next higher subunit (or unit) should be moved
        fi=fi-1;% move to a higher subunit, or if fi == 0 exit loop because we are at the year unit
        fnum = fnum_new; % if this is zero, exit loop
    end
    % if the loop was stopped because "fnum" was zero, we're done -- we don't need to adjust higher subunits of "tve";
    % however, the loop might have stopped because fi == 0, in which case we need to move the year value
    if fnum ~= 0
        tve(1) = tvs(1)+fnum;
    end
end
% now "tve" exists
tve = reshape(tve,1,length(tve));% ensure "tve" is row vector

% 'tve' option -- return "tve" right now
if strmatch(option,'tve')
    tma = tve;
    return
end

singles_end = utl_sngl_tm_vctr([tvs;tve],freq);
if diff(singles_end) == 0 % "tve" is the same as "tvs" -- it must have been given the same, since if "num"=0 we'd have returned above
    tma = tvs;
    return
end

switch (singles_end(1) < singles_end(2)) % we have taken care already of the case that singles_end(1)==singles_end(2)
    case 1 % "tvs" is before "tve"
        tvs_real = tvs(1:fn+1);tve_real=tve(1:fn+1);
        tvsfirst = 1;
    case 0 % "tve" is before "tvs"
        tvs_real = tve(1:fn+1);tve_real=tvs(1:fn+1);
        tvsfirst = 0;
        singles_end = flipud(singles_end);% rearrange "singles_end" in ascending order
end

% Find how many steps we will make
singles = [singles_end(1): 1/prod(freq) : singles_end(2)]';
steps = length(singles)-1;
if strmatch(option,'diff')
    tma = steps;
    return
end

% If we haven't returned yet, we are required to construct the time array
freq = reshape(freq,1,fn);% ensure "freq" is row vector
tma = repmat(tvs_real,steps+1,1);
fi = fn;
fsteps = [0:steps]';
while (fi > 0) & (max(fsteps) ~= 0) % either we've gotten to the year unit, or there is no more need to move higher subunits
    tma(:,fi+1) = tma(:,fi+1) + fsteps; % take the proper steps in the units "fi+1" is currently at
    fsteps = (tma(:,fi+1)-1)/freq(fi); % translate the steps of units "fi+1" into steps of units "fi" -- might be zero
    tma(:,fi+1) = 1+ mod( tma(:,fi+1)-1, freq(fi) ); % mod the "fi+1" units
    fsteps = floor(fsteps);
    fi = fi-1;
end
tma(:,1) = tma(:,1) + fsteps;
% If we ignored subunits with the construction of "tma" above, we just put the ignored subunits of "tvs" for every row
if length(tvs_real) ~= length(tvs)
    tma(:,length(tvs_real)+1:length(tvs)) = repmat(tvs(1,length(tvs_real)+1:end),size(tma,1),1);
end
% Flip back if "tvs" was after "tve"
if tvsfirst == 0
    tma = flipud(tma);
end


