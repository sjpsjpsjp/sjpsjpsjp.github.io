function out = utl_ar_prcss(A,varargin)
% ARprocess = utl_ar_prcss(arcoefs,varargs)
% inputs
% - arcoefs : n-x-n matrix (for n, number of elements in process, integer greater than zero) for AR(1) process, or p-dim cell-array of n-x-n matrix for AR(p) process
% - varargs : any one of the following combos
%     + 'cons' : a scalar or n-dim vector for constant (default zero(s))
%     + 'T' : scalar number of time periods in process output (default 200)
%     + 'burn' : scalar number of time periods to burn from initializing values (default 0) [number of periods output still is whatever 'T' is set or default]
%     + 'init' : n-x-p matrix to start process (default zero(s)) [earlier to left, more recent to right]
%     + 'cov' : n-x-n covariance matrix of innovations (default identity)
%     + 'dist' : string indicating distribution of innovations (default normal) from following options:
%         - 'norm'
% 
% outputs
% - ARprocess : n-dimensional autoregressive process of 'T' periods; a n-x-T matrix; time goes left to right
% 

%% Defaults
% determine dimension n and order p
switch iscell(A)
    case 0 % AR(1) process
        if size(A,1) ~= size(A,2); error('utl_ar_prcss: The AR(1) coefficient is not square'); end;
        p = 1;
        n = size(A,1);
    case 1 % AR(p) process
        p = length(A);
        for i=(1:p)
            if size(A{i},1) ~= size(A{i},2); error(['utl_ar_prcss: The AR(' num2str(i) ') coefficient is not square']); end;
        end
        n = size(A{1},1);
        A = [A{:}];
end
% fill defaults
cons = zeros(n,1);
T = 200;
burn = 0;
init = zeros(n,p);
cov = eye(n);
dist = @randn; possdist = {'norm'};
% look for passed varargs
if (rem(nargin,2) == 0 || nargin < 1)
    error('utl_ar_prcss: Incorrect number of arguments ');
end
okargs = {'cons','T','burn','init','cov','dist'};
for j=1:2:(nargin-2)
    pname = varargin{j};
    pval = varargin{j+1};
    k = strmatch(pname,okargs);
    if isempty(k)
        error(['utl_ar_prcss: Unknown parameteer name: ' pname]);
    elseif length(k)>1
        error(['utl_ar_prcss: Ambiguous parameter name: ' pname]);
    else
        switch k
            case {1,2,3,4,5}
                eval([pname '= pval;']);
            case 6 % 'dist'
                dist = @randn;
                % Following does not yet work
%                 kk = strmatch(lower(pval),possdist);
%                 if isempty(k)
%                     error('utl_ar_prcss: ','Unknown distribution name: %s.',pval);
%                 elseif length(k)>1
%                     error('utl_ar_prcss: ','Ambiguous distribution name: %s.',pval);
%                 else
%                     distflag = 1;
%                 end
        end
    end
end

burnT = burn+T;
cons = cons(:); % make sure its a column vector
out = zeros(n,burnT);
% we fill this from right to left, and then flip it at the end. We do this because it enables the reshape command to
% vectorize the lags of the process values in the right way with the natural orientation of the AR coefficients (which is in
% a matrix [A1 A2 ... Ap] where A1 is the coefficient matrix on the first lag, etc.).
out(:,burnT-(p-1):burnT) = fliplr(init);
innovations = dist(size(out,1),size(out,2)); % this innovation matrix is bigger than we need, but is done for legibility below
chcov = chol(cov);
for j=fliplr([1:burnT-p])
    out(:,j) = A*reshape(out(:,j+1:j+p),n*p,1) ... dynamics
                + cons ... constant term
                + chcov*innovations(:,j); % innovation
end
out = fliplr(out);
out = out(:,burn+1:burnT);

                            







