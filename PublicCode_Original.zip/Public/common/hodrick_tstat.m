function [t_hod t_ols] = hodrick_tstat(betas,e,X,K)

% Predictive Regression t-stats using Hodrick (1992) standard errors
% e = vector of forecasting errors
% X = lagged predictor matrix
% K = periods aggregated 
%
% NOTES: 
% 1) K=1 is no overlap, K=2 is one period overlap, etc.
% 2) e(t) and X(t) should line up so that X(t) is the obs that produced e(t).
%    That is, X(t) should be lag of predictor

temp = sum([e X],2);
e    = e(~isnan(temp));
X    = X(~isnan(temp),:);
clear temp

[T,Nx] = size(X);

% Calculate OLS t-stats
Exx = zeros(size(X,2));
for t=1:T;
    Exx = Exx + X(t,:)'*X(t,:);
end
Exx = Exx/T;
se_ols = sqrt( diag( nanvar(e)*inv(Exx) )/T ); 

% Calculate Hodrick t-stats
if K==1, 
else
    S = zeros(Nx);
    for t=1:length(e)-K;
        wK = e(t+K)*nansum(X(t:t+K-1,:));
        S = S + wK'*wK;
    end
    S = S/T;
    se = sqrt( diag( inv(Exx)*S*inv(Exx) )/T/K );         
end
    
% t_hod = abs(betas(2:end,:)./se);
t_hod = betas(2:end,:)./se; 
t_ols = abs(betas(2:end,:)./se_ols);    
  
    
%#ok<*MINV>