function [rhos vols] = ar1_calc(x,pds)


rhos = nan(1,pds); vols = nan(1,pds);
for j=1:pds
    y       = utl_dmn( x(j:pds:end) );
    rhos(j) = regress(y(2:end),y(1:end-1));
    vols(j) = nanstd(y);
end

disp(' ')
disp('rhos')
disp(num2str(rhos))
disp([' mean   ' num2str(mean(rhos))])
disp([' median ' num2str(median(rhos))])
disp(' ')
disp('vols')
disp(num2str(vols))
disp([' mean   ' num2str(mean(vols))])
disp([' median ' num2str(median(vols))])