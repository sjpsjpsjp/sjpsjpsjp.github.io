% Results_Main_2016
%
% Estimates inflation and real activity response coefficients implied by the median Blue Chip
% forecasts or historical data
%
% Also use historical data

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
% Preliminaries
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
clear;
addpath(genpath('utl'))
rmpath(genpath('utl\spatial_econometrics\ucsd_garch'))

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
% Choices and Specifications
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5

    
% datachoice : 'bluechip' (default) or 'historical', 'bluechip difference', 'historical difference'
datachoice = 'historical';

% Select the regimes
regimes =   [ 1980 1; ...
              2011 8; ...
              2014 12]; % to use all data, put in first-row and last-row that is before/after every observation  
regname = '201108';
          
%exclude = [];% empty exclude no period, otherwise a matrix like [2008 1;2008 12] with obs to exclude

bootsims = 1000;% number of bootsims -- if empty, bootstrap not run

% constant *-variables
constantstar = 'off';
constantr    = 2.25;
constantpi   = 2.5;
constantreal = 5.75;

% savefilename -- name of file; if empty, no file saved
samname = regnames([regimes(1,:);regimes(end,:)]);
%excname = excnames(exclude);
%consstarname = ''; if strcmp(constantstar,'on'); consstarname = '_constantstars'; end
savefilename = ['' datachoice '_' samname '_' regname];


load BC_and_H

% savefiledir -- where the results are saved
savefiledir = '../Data/';



% Select the BC variables
nname  = 'RFF_FF'; % 'RT3M_FF', 'RFF_FF', 'RTB_EI'
nsname = 'RFF_FF'; % RT3M, RFF_FF, RT3M_FF
iname  = 'GCPI_FF'; % 'GPGDP_EI','GCPI_EI','GPGDP_FF','GCPI_FF'
isname = 'GCPI_FF'; % GPGDP_FF, GCPI_FF, GPDGP, GCPI
rname  = 'RU_EI'; % 'RU_EI', GGDP_FF
rsname = 'RU'; % RU, RU_GGDP_EI, RU_GGDP_FF

% Select the historical variables
hnname = 'FF';
hiname = 'CORECPI';
hrname = 'RU';   
          
          
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Bring in data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

nreg = size(regimes,1)-1;


    
% long range fill in (from reading the June 2011)
times  = [year(BC.(nname).dates) month(BC.(nname).dates)]; % Available data sample
times2 = BC.(nname).dates;
% choose how one-year-ahead BC variables are constructed
nominalrate   = BC.(nname).F4;
nominalratelg = BC.(nname).F3;
inflationrate = nanmean([BC.(iname).F1 BC.(iname).F2 BC.(iname).F3 BC.(iname).F4],2);
realactivity  = BC.(rname).F4;%nanmean([BC.(rname).F1 BC.(rname).F2 BC.(rname).F3 BC.(rname).F4],2);

% expand lr vectors with nans
tmp = fieldnames(lr);
for j=1:length(tmp)
    jn       = tmp{j};
    x        = nan(size(nominalrate));
    loc      = ismember(times2,lr.dates-1);
    x(loc,:) = lr.(jn);
    lr.(jn)  = x;
end
% put all Flong into lr
tmp = fieldnames(BC);
for j=1:length(tmp)
    jn = tmp{j};
    try lr.(jn) = BC.(jn).Flong;
    end
end
% run regression of RU on GGDP in BCEI, use to fit values for GGDP in BCEI or BCFF
lrr = regstats(lr.RU(end-40:end),lr.GGDP(end-40:end),'linear','all');
lr.RU_GGDP_EI = ~isnan(lr.GGDP)*lrr.beta(1) + lr.GGDP*lrr.beta(2);
lr.RU_GGDP_FF = ~isnan(BC.GGDP_FF.Flong)*lrr.beta(1) + BC.GGDP_FF.Flong*lrr.beta(2);
% choose long-run BC variables and linearly interpolate
pistar        = lr.(isname);
realstar      = lr.(rsname);
X             = [pistar realstar lr.(nsname)];
X             = fillin(X,'linear');
pistar        = X(:,1);
realstar      = X(:,2);
rstar         = X(:,3)-X(:,1);


if strcmp(constantstar,'on')
    % Choose constant star variables
    rstar    = constantr*ones(size(rstar));
    pistar   = constantpi*ones(size(pistar));
    realstar = constantreal*ones(size(realstar));
end
% star variables -- both bluechip and historical now
rstar = [rstar rstar];  rstar(end-10:end,:) = fillin(rstar(end-10:end,:),'nearest','extrap');
pistar = [pistar pistar];  pistar(end-10:end,:) = fillin(pistar(end-10:end,:),'nearest','extrap');
realstar = [realstar realstar];  realstar(end-10:end,:) = fillin(realstar(end-10:end,:),'nearest','extrap');

% regular variables -- both bluechip and historical now
inflationrate = fillin(inflationrate,'linear');
realactivity  = fillin(realactivity,'linear');
nominalrate   = fillin(nominalrate,'linear');
nominalratelg = fillin(nominalratelg,'linear');
inflationrate(:,2) = nanmean([H.(hiname).x mlag(H.(hiname).x,3)],2);
realactivity(:,2)  = H.(hrname).x;%nanmean([H.(hrname).x mlag(H.(hrname).x,3)],2);
nominalrate(:,2)   = H.(hnname).x;
nominalratelg(:,2) = [nan; H.(hnname).x(1:end-1)];

termspread = H.TBOND10Y.x-H.TBOND2Y.x;

switch datachoice
    case 'bluechip'
        rstar         = rstar(:,1);
        pistar        = pistar(:,1);
        realstar      = realstar(:,1);
        inflationrate = inflationrate(:,1);
        realactivity  = realactivity(:,1);
        nominalrate   = nominalrate(:,1);
        nominalratelg = nominalratelg(:,1);
    case 'historical'
        rstar         = rstar(:,2);
        pistar        = pistar(:,2);
        realstar      = realstar(:,2);
        inflationrate = inflationrate(:,2);
        realactivity  = realactivity(:,2);
        nominalrate   = nominalrate(:,2);
        nominalratelg = nominalratelg(:,2);
    case 'bluechip_difference'
        rstar         = [nan; diff(rstar(:,1))];
        pistar        = [nan; diff(pistar(:,1))];
        realstar      = [nan; diff(realstar(:,1))];
        inflationrate = [nan; diff(inflationrate(:,1))];
        realactivity  = [nan; diff(realactivity(:,1))];
        nominalrate   = [nan; diff(nominalrate(:,1))];
        nominalratelg = [nan; diff(nominalratelg(:,1))];
    case 'historical_difference'
        rstar         = [nan; diff(rstar(:,2))];
        pistar        = [nan; diff(pistar(:,2))];
        realstar      = [nan; diff(realstar(:,2))];
        inflationrate = [nan; diff(inflationrate(:,2))];
        realactivity  = [nan; diff(realactivity(:,2))];
        nominalrate   = [nan; diff(nominalrate(:,2))];
        nominalratelg = [nan; diff(nominalratelg(:,2))];
    otherwise
        rstar         = rstar(:,1);
        pistar        = pistar(:,1);
        realstar      = realstar(:,1);
        inflationrate = inflationrate(:,1);
        realactivity  = realactivity(:,1);
        nominalrate   = nominalrate(:,1);
        nominalratelg = nominalratelg(:,1);
        datachoice = 'bluechip';
end


disp(savefilename)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
% Routine
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5

% Set regime vector
Regimes = zeros( size(times,1) , 1 );
% first regime -- at start, or later?
j = find(ismember(times,regimes(1,:),'rows'),1,'first');
if isempty(j); j = 1; end;
Regimes(j:end) = 1;
% find all following regimes
for r = 2:size(regimes,1);
    j = find(ismember(times,regimes(r,:),'rows'),1,'first');
    if isempty(j) || j==size(times,1) % this row is after available data or the last data point
        break
    else
        Regimes(j:end) = Regimes(j:end) + 1;
    end
end

Regimes( Regimes>nreg ) = 0;
I = Regimes>0;
g = sum(isnan([nominalrate nominalratelg inflationrate realactivity pistar realstar rstar]),2)==0;

% % Exclude period
% if ~isempty(exclude)
%     esi = find(ismember([year(times2) month(times2)],exclude(1,:),'rows'));
%     eei = find(ismember([year(times2) month(times2)],exclude(2,:),'rows'));
%     g(esi:eei) = false;
% end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Regression
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
% Create zeroed-out variables for big regression
PI = zeros(size(nominalrate,1),nreg); U = PI; PI00 = PI; U00 = U; Q = PI;
C  = U;

for r = 1:nreg
    Rr = Regimes==r;
    % Fill split regression variables
    PI(Rr&g,r)   = inflationrate(Rr&g);
    PIst(Rr&g,r) = inflationrate(Rr&g)-pistar(Rr&g);
    U(Rr&g,r)    = realactivity(Rr&g);
    Ust(Rr&g,r)  = realactivity(Rr&g)-realstar(Rr&g);
    C(Rr&g,r)    = 1;
    Q(Rr&g,r)    = rstar(Rr&g)+pistar(Rr&g);
end


% Construct non-split variables
y       = nominalrate;
yst     = nominalrate - rstar - pistar;
ylg     = nominalratelg - rstar - pistar;
PI_nb   = sum(PI,2);
PIst_nb = sum(PIst,2);
U_nb    = sum(U,2);
Ust_nb  = sum(Ust,2);

y(y<0.25) = 0;

% The following is hard-coded to only accept two regimes at most

% LS with *-variables and PI/U breaks
reg_star = nwest( ...
    yst(I&g) , [PIst(I&g,:) Ust(I&g,:) ] , 3);
% Tobit LS with *-variables and PI/U breaks
tobit_star = constrainedtobit( y(I&g) , ...
    [Q(I&g,:) PIst(I&g,:) Ust(I&g,:) ] , [ones(nreg,1);nan(2*nreg,1)] );

% LS with *-variables no U break
reg_star_Unb = nwest( ...
    yst(I&g) , [PIst(I&g,:) Ust_nb(I&g,:) ] , 3);
% Tobit LS with *-variables and no U break
tobit_star_Unb = constrainedtobit( y(I&g) , ...
    [Q(I&g,:) PIst(I&g,:) Ust_nb(I&g,:) ] , [ones(nreg,1);nan(nreg,1);nan] ); 

% LS with *-variables no PI break
reg_star_PInb = nwest( ...
    yst(I&g) , [PIst_nb(I&g,:) Ust(I&g,:) ] , 3);
% Tobit LS with *-variables and no PI break
tobit_star_PInb = constrainedtobit( y(I&g) , ...
    [Q(I&g,:) PIst_nb(I&g,:) Ust(I&g,:) ] , [ones(nreg,1);nan;nan(nreg,1)] ); 

% LS with *-variables no U/PI break
reg_star_UnbPInb = nwest( ...
    yst(I&g) , [PIst_nb(I&g,:) Ust_nb(I&g,:) ] , 3);
% Tobit LS with *-variables and no U/PI break
tobit_star_UnbPInb = constrainedtobit( y(I&g) , ...
    [Q(I&g,:) PIst_nb(I&g,:) Ust_nb(I&g,:) ] , [ones(nreg,1);nan;nan] ); 

% For fig
forfig = constrainedtobit( y(I&g) , ...
    [Q(I&g,:) PIst(I&g,:) Ust(I&g,:) termspread(I&g,1)] , [ones(nreg,1);nan(2*nreg+1,1)] );

if ~isempty(bootsims)
    bootwin             = 6;
    bs                  = (1:sum(I&g))';
    bs(end-bootwin:end) = false;
    
    boot.reg_star           = nan( length(reg_star.beta),           bootwin );
    boot.tobit_star         = nan( length(tobit_star.beta),         bootwin );
    boot.reg_star_Unb       = nan( length(reg_star_Unb.beta),       bootwin );
    boot.tobit_star_Unb     = nan( length(tobit_star_Unb.beta),     bootwin );
    boot.reg_star_PInb      = nan( length(reg_star_PInb.beta),      bootwin );
    boot.tobit_star_PInb    = nan( length(tobit_star_PInb.beta),    bootwin );
    boot.reg_star_UnbPInb   = nan( length(reg_star_UnbPInb.beta),   bootwin );
    boot.tobit_star_UnbPInb = nan( length(tobit_star_UnbPInb.beta), bootwin );
    
    bK                  = ceil(sum(I&g)/bootwin);
    bstarts             = randi([min(find(bs)) max(find(bs))],bK,bootsims);
    for bsim = 1:bootsims
        bss   = bsxfun(@plus,bstarts(:,bsim),[0:1:bootwin-1]);
        bssi  = vec(bss');
        bssi2 = bssi(1:length(reg_star.yhat));
        
        ybs                   = reg_star.yhat + reg_star.resid(bssi2);
        tmp                   = nwest( ybs , [PIst(I&g,:) Ust(I&g,:) ] , 3);
        boot.reg_star(:,bsim) = tmp.beta;
        
        ybs                       = reg_star_Unb.yhat + reg_star_Unb.resid(bssi2);
        tmp                       = nwest( ybs , [PIst(I&g,:) Ust_nb(I&g,:) ] , 3);
        boot.reg_star_Unb(:,bsim) = tmp.beta;
        
        ybs                        = reg_star_PInb.yhat + reg_star_PInb.resid(bssi2);
        tmp                        = nwest( ybs , [PIst_nb(I&g,:) Ust(I&g,:) ] , 3);
        boot.reg_star_PInb(:,bsim) = tmp.beta;
        
        ybs                           = reg_star_UnbPInb.yhat + reg_star_UnbPInb.resid(bssi2);
        tmp                           = nwest( ybs , [PIst_nb(I&g,:) Ust_nb(I&g,:) ] , 3);
        boot.reg_star_UnbPInb(:,bsim) = tmp.beta;
        
        ybs = tobit_star.yhat + tobit_star.resid(bssi2);
        tmp = constrainedtobit( ybs , [Q(I&g,:) PIst(I&g,:) Ust(I&g,:) ] , [ones(nreg,1);nan(2*nreg,1)] );
        boot.tobit_star(:,bsim) = tmp.beta;
        
        ybs = tobit_star_Unb.yhat + tobit_star_Unb.resid(bssi2);
        tmp = constrainedtobit( ybs , [Q(I&g,:) PIst(I&g,:) Ust_nb(I&g,:) ] , [ones(nreg,1);nan(nreg,1);nan] );
        boot.tobit_star_Unb(:,bsim) = tmp.beta;
        
        ybs = tobit_star_PInb.yhat + tobit_star_PInb.resid(bssi2);
        tmp = constrainedtobit( ybs , [Q(I&g,:) PIst_nb(I&g,:) Ust(I&g,:) ] , [ones(nreg,1);nan;nan(nreg,1)] );
        boot.tobit_star_PInb(:,bsim) = tmp.beta;
        
        ybs = tobit_star_UnbPInb.yhat + tobit_star_UnbPInb.resid(bssi2);
        tmp = constrainedtobit( ybs , [Q(I&g,:) PIst_nb(I&g,:) Ust_nb(I&g,:) ] , [ones(nreg,1);nan;nan] );
        boot.tobit_star_UnbPInb(:,bsim) = tmp.beta;
        
    end
    
    reg_star.bootse        = nanstd(boot.reg_star')';
    reg_star_Unb.bootse    = nanstd(boot.reg_star_Unb')';
    reg_star_PInb.bootse   = nanstd(boot.reg_star_PInb')';
    reg_starUnbPInb.bootse = nanstd(boot.reg_star_UnbPInb')';
    
    tobit_star.bootse         = nanstd(boot.tobit_star')';
    tobit_star_Unb.bootse     = nanstd(boot.tobit_star_Unb')';
    tobit_star_PInb.bootse    = nanstd(boot.tobit_star_PInb')';
    tobit_star_UnbPInb.bootse = nanstd(boot.tobit_star_UnbPInb')';

end















