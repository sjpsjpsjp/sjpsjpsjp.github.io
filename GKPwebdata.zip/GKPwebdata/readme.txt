

This folder contains systemic risk measures constructed in 
Giglio, Kelly, and Pruitt (Journal of Financial Economics, 
forthcoming).  Data for the US are in “usmeasures.csv” and 
data for UK and Europe are in “intlmeasures.csv”.  The 
variable names correspond directly to the names of systemic 
risk measures in the paper.  In addition, we provide the 
“pqr” measure for each region.  This is the full sample 
(i.e., in-sample) pqr systemic risk index constructed for 
20th percentile forecasts of industrial production growth 
in each region.

Prepared: June 11, 2015