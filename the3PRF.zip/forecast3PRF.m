function [forecasts] = forecast3PRF(y,X,Z,varargin)
% [forecasts] = forecast3PRF(y,X,Z)
% [forecasts] = forecast3PRF(y,X,Z,flag1,value1,...)
%
% INPUTS
% - y  : (T x 1) time series of target variable
% - X  : (T x N) matrix of predictors' time series
% - Z  : (T x L) matrix of proxies' time series 
%            OR
%         scalar choice for choice of L automatic proxies.
%
%     NOTE: The timing between y and X/Z must be adjusted before being passed. We assume that
%     the t-th row of X is being used to forecast the t-th row of y, and that the t-th row of Z
%     are the proxies used to extract info from the t-th row of X.  This means that y (or X/Z)
%     should be properly led (lagged) before being passed.
%
%     *Flags*
%     - 'type' : 'IS Full' (default), 'OOS Recursive', 'OOS Cross Val'
%
%     - 'window' : 2-vector such as [ <number of obs before forecasted to drop> , <number of obs
%     total to drop> ], used by OOS Cross Val (default [0 1])
%
%     - 'mintrain' : EITHER 
%         (1) scalar choice of smallest number of observations for training sample, used by OOS
%         Recursive (default = round(T/2))
%             OR
%         (2) 2-vector with smallest number as in (1) and gap between training estimation window and
%         first forecast constructed (default = 0)
%
%     - 'pls' : 'on' or 'off' (default), runs PLS version which runs 1st and 2nd
%     stages without constants [only if scalar is passed for Z]
%
% OUTPUTS
% - forecasts : (T x 1) time series of forecasts
%
% DESCRIPTION: Computes Three-Pass Regression Filter (Bryan Kelly and Seth Pruitt, ``The Three-Pass
% Regression Filter: A New Approach to Forecasting Using Many Predictors''); see paper for more
% details.
%
% Please cite as: Kelly, Bryan and Seth Pruitt (2011): ``The Three-Pass Regression Filter: A New
% Approach to Forecasting Using Many Predictors,'' Working Paper, Chicago Booth.
%
% Assumes the data are timed as follows:
%   - y = (y[h+1] ,y[h+2] ,...,y[T+h])'
%   - X = (x[1]',  x[2]'  ,...,x[T]' )'
% A future realized variable (like the target itself) might be one of the proxies, as well as other
% variables realized at time t+h.
%
% Requires Stats toolbox (nanstd.m,nanmean.m,regress.m)

% Copyright 2010-2011, Bryan Kelly and Seth Pruitt
% First Version: 2010-12-30 This Version: 2012-9-13


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Preliminary Checking
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% size checking
[T tmp] = size(y);
if tmp~=1, error(['y should have col dim 1, but has col dim ' num2str(tmp)]), end
[tmp N] = size(X);
if tmp~=T, error(['X should have row dim ' num2str(T) ' like y, but has row dim ' num2str(tmp)]), end
[tmp L] = size(Z); 
if isscalar(Z), autoproxy = 'on'; L=Z;
elseif tmp~=T, error(['Z should have row dim ' num2str(T) ' like y, but has row dim ' num2str(tmp)]),
else autoproxy = 'off';end

% check for flags
if nargin > 3, flagspassed = true; else flagspassed = false; end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Flag/Paramater Combos
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Flags we look for
possibleflags = {'type','window','mintrain','pls'};
possibletypes = {'IS Full' ; ...
                'OOS Recursive'; ...
                'OOS Cross Val'};

% Defaults
procedure   = 'IS Full'; % IS Full
window      = [0 1]; % one observation between last estimation obs and first forecast obs, three dropped observations altogether
mintrain    = round(T/2); % 1st element default: first training sample is half as long as full sample
pls         = 0;

if flagspassed
    for fl=1:2:nargin-3
        flag = varargin{fl};
        fval = varargin{fl+1};
        fm = strmatch(flag,possibleflags);
        if isempty(fm)
            error(['Unknown flag name -- ' flag])
        elseif length(fm)>1
            error(['Ambiguous flag name -- ' flag])
        end % if we get through here, the flag is uniquely recognizable
        
        switch flag
            case 'type'
                tm   = strmatch(fval,possibletypes(:,1),'exact');
                if isempty(tm)
                    error(['Unknown type name -- ' fval])
                elseif length(tm)>1
                    error(['Ambiguous type name -- ' fval ' -- going with default'])
                end % if we get through here, the type is uniquely recognizable
                procedure = fval;
                
            case 'window'
                window = fval;
            case 'mintrain'
                mintrain = fval;
            case 'pls'
                pls = strcmp(fval,'on');
        end
        
    end
end

% 2nd element of mintrain default
if isscalar(mintrain), mintrain = [mintrain 0]; end

% pls=1 only if autoproxy=1
if pls==1 && strcmp(autoproxy,'off'), pls=0; end

% Unit variance for X
X = X ./ repmat( nanstd(X) , size(X,1) , 1 );







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Forecast Construction
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

switch procedure
    
    case 'IS Full'
        if strcmp(autoproxy,'on')
            r0 = y;
            for j=1:L
                forecasts = t3prf(y,X,r0,pls);
                r0 = [r0 y-forecasts];
                if nargout>1 && j==L
                    Z = r0(:,1:end-1);
                end
            end
        else
            forecasts = t3prf(y,X,Z,pls);
        end
            
        
    case 'OOS Cross Val'
        if strcmp(autoproxy,'on')
            forecasts = nan(size(y));
            for t=1:T
                Tscript = setdiff( 1:T , t-window(1):t-window(1)+window(2)-1 );
                yt = y(Tscript,1); Xt = X(Tscript,:);
                Xts=nanstd(Xt); Xt = bsxfun(@rdivide,Xt,Xts);
                r0 = yt;
                for j=1:L
                    [tmp tmpt] = t3prf(yt,Xt,r0,pls,X(t,:)./Xts);
                    r0  = [yt-tmp r0];
                end
                forecasts(t) = tmpt;
            end
        else
            forecasts = nan(size(y));
            for t=1:T
                Tscript = setdiff( 1:T , t-window(1):t-window(1)+window(2)-1 );
                yt = y(Tscript,1); Xt = X(Tscript,:); Zt = Z(Tscript,:);
                Xts=nanstd(Xt); Xt = bsxfun(@rdivide,Xt,Xts);
                [tmp tmpt] = t3prf(yt,Xt,Zt,pls,X(t,:)./Xts);
                forecasts(t) = tmpt;
            end
        end
        
    case 'OOS Recursive'
        if strcmp(autoproxy,'on')
            forecasts = nan(size(y));
            for t=mintrain(1)+1+abs(mintrain(2)):T
                Tscript = 1:t-1-abs(mintrain(2));
                yt = y(Tscript,1); Xt = X(Tscript,:);
                Xts=nanstd(Xt); Xt = bsxfun(@rdivide,Xt,Xts);
                r0 = yt;
                for j=1:L
                    [tmp tmpt] = t3prf(yt,Xt,r0,pls,X(t,:)./Xts);
                    r0  = [yt-tmp r0];
                end
                forecasts(t) = tmpt;
            end
        else
            forecasts = nan(size(y));
            for t=mintrain(1)+1+abs(mintrain(2)):T
                Tscript = 1:t-1-abs(mintrain(2));
                yt = y(Tscript,1); Xt = X(Tscript,:); Zt = Z(Tscript,:);
                Xts=nanstd(Xt); Xt = bsxfun(@rdivide,Xt,Xts);
                [tmp tmpt] = t3prf(yt,Xt,Zt,pls,X(t,:)./Xts);
                forecasts(t) = tmpt;
            end
        end
        
    otherwise %IS Full
        if strcmp(autoproxy,'on')
            r0 = y;
            for j=1:L
                forecasts = t3prf(y,X,r0,pls);
                r0 = [y-forecasts r0];
            end
        else
            forecasts = t3prf(y,X,Z,pls);
        end
                
end

           



end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% END OF MAIN FUNCTION
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% NonNested Helper Functions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%
% t3prf
%%%%%%%
function [yhat yhatt] = t3prf(y,X,Z,pls,varargin)

% Preliminaries
N     = size(X,2);
T     = size(y,1);
L     = size(Z,2);
Phi   = nan(N,L);
Sigma = nan(T,L);

if pls
    Xm = nanmean(X);
    Xd = X - repmat(Xm,T,1);
end

% 3PRF
for i=1:N
    if pls
        phi      = regress( Xd(:,i) , Z );
        Phi(i,:) = phi(1:end);
    else
        phi      = regress( X(:,i) , [iota(T) Z] );
        Phi(i,:) = phi(2:end);
    end
end
for t=1:T
    if pls
        sigma      = regress( Xd(t,:)' , Phi );
        Sigma(t,:) = sigma(1:end);      
    else
        sigma      = regress( X(t,:)' , [iota(N) Phi] );
        Sigma(t,:) = sigma(2:end);
    end
end
beta  = regress( y , [iota(T) Sigma] );
yhat = [iota(T) Sigma]*beta;

% Out-of-sample forecast construction, if called
yhatt = nan;
if nargin>4 % varargin contains the an out-of-sample x to create an out-of-sample forecast
    Xt = varargin{1}; % should be a row vector
    if pls
        sigma = regress( Xt'-Xm'           , Phi  );
        yhatt = [1 sigma(1:end)']*beta;
    else
        sigma = regress( Xt'      , [iota(N) Phi] );
        yhatt = [1 sigma(2:end)']*beta;
    end
end
end

%%%%%%
% iota
%%%%%%
function out = iota(NorT)
out = ones(NorT,1);
end
